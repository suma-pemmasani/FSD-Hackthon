import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Sparkles, 
  Send, 
  Code, 
  FileText, 
  HelpCircle, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  ChevronRight, 
  Layers, 
  Lightbulb, 
  Eye,
  Play
} from 'lucide-react';
import { Interview, Question, Evaluation } from '../types';
import { SpeechService } from '../services/speech';

interface InterviewRoomProps {
  interview: Interview;
  onEvaluateAnswer: (questionId: number, answerText: string, codeSnippet?: string, duration?: number) => Promise<Evaluation>;
  onFinishInterview: () => Promise<void>;
  isSubmitting: boolean;
}

export const InterviewRoom: React.FC<InterviewRoomProps> = ({
  interview,
  onEvaluateAnswer,
  onFinishInterview,
  isSubmitting
}) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [candidateAnswer, setCandidateAnswer] = useState('');
  const [codeSnippet, setCodeSnippet] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [audioMuted, setAudioMuted] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [activeInputTab, setActiveInputTab] = useState<'verbal' | 'code' | 'star'>('verbal');
  const [showStarHelper, setShowStarHelper] = useState(false);
  
  // STAR helper state
  const [starS, setStarS] = useState('');
  const [starT, setStarT] = useState('');
  const [starA, setStarA] = useState('');
  const [starR, setStarR] = useState('');

  // Timer
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Instant evaluation per question
  const [currentEvaluation, setCurrentEvaluation] = useState<Evaluation | null>(null);
  const [showExpectedHints, setShowExpectedHints] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<any>(null);

  const currentQuestion: Question | undefined = interview.questions[currentIdx];

  // Initialize Question and speak
  useEffect(() => {
    if (!currentQuestion) return;

    // Check if question already has an answer / evaluation
    if (currentQuestion.answer?.candidateAnswer) {
      setCandidateAnswer(currentQuestion.answer.candidateAnswer);
      setCodeSnippet(currentQuestion.answer.codeSnippet || '');
      setCurrentEvaluation(currentQuestion.answer.evaluation || null);
    } else {
      setCandidateAnswer('');
      setCodeSnippet(currentQuestion.starterCode || '');
      setCurrentEvaluation(null);
    }

    setElapsedSeconds(0);
    setShowExpectedHints(false);

    // Speak question aloud if not muted
    if (!audioMuted) {
      speakCurrentQuestion();
    }

    // Switch to code tab automatically if coding question
    if (currentQuestion.category === 'CODING') {
      setActiveInputTab('code');
    } else {
      setActiveInputTab('verbal');
    }

    return () => {
      SpeechService.stopSpeaking();
      SpeechService.stopListening();
    };
  }, [currentIdx, interview.id]);

  // Elapsed timer
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIdx]);

  // Camera stream handler
  useEffect(() => {
    if (cameraActive) {
      navigator.mediaDevices?.getUserMedia({ video: true, audio: false })
        .then(stream => {
          streamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch(err => {
          console.warn('Webcam permission note:', err);
          setCameraActive(false);
        });
    } else {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
    }

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraActive]);

  const speakCurrentQuestion = () => {
    if (!currentQuestion) return;
    setIsAiSpeaking(true);
    SpeechService.speak(
      currentQuestion.questionText,
      interview.interviewerName,
      () => setIsAiSpeaking(true),
      () => setIsAiSpeaking(false)
    );
  };

  const toggleRecording = () => {
    if (isRecording) {
      SpeechService.stopListening();
      setIsRecording(false);
    } else {
      // Stop AI voice if speaking
      SpeechService.stopSpeaking();
      setIsAiSpeaking(false);

      const success = SpeechService.startListening(
        (transcript) => {
          setCandidateAnswer(prev => {
            if (!prev) return transcript;
            return prev.endsWith(' ') ? prev + transcript : prev + ' ' + transcript;
          });
        },
        (err) => {
          console.warn(err);
          setIsRecording(false);
        },
        () => {
          setIsRecording(false);
        }
      );

      if (success) {
        setIsRecording(true);
      }
    }
  };

  const handleApplyStar = () => {
    const combined = `[Situation]: ${starS.trim()} \n[Task]: ${starT.trim()} \n[Action]: ${starA.trim()} \n[Result]: ${starR.trim()}`;
    setCandidateAnswer(combined);
    setShowStarHelper(false);
    setActiveInputTab('verbal');
  };

  const handleSubmitAnswer = async () => {
    if (!currentQuestion) return;
    const finalAnswer = candidateAnswer.trim() || (codeSnippet.trim() ? 'Please refer to the code implementation provided below.' : '');

    if (!finalAnswer) {
      alert('Please speak or type your answer before submitting.');
      return;
    }

    SpeechService.stopListening();
    setIsRecording(false);

    try {
      const evalResponse = await onEvaluateAnswer(
        currentQuestion.id,
        finalAnswer,
        codeSnippet.trim() ? codeSnippet : undefined,
        elapsedSeconds
      );
      setCurrentEvaluation(evalResponse);
    } catch (err: any) {
      console.error('Failed to evaluate answer:', err);
    }
  };

  const handleNext = () => {
    SpeechService.stopSpeaking();
    SpeechService.stopListening();
    setIsRecording(false);
    if (currentIdx < interview.questions.length - 1) {
      setCurrentIdx(prev => prev + 1);
    } else {
      onFinishInterview();
    }
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Session Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <span className="font-bold text-xs">{currentIdx + 1} / {interview.questions.length}</span>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-bold text-white">{interview.role}</span>
              <span className="px-2 py-0.5 text-[10px] font-semibold uppercase bg-slate-800 text-slate-300 border border-slate-700 rounded-md">
                {interview.companyType}
              </span>
            </div>
            <p className="text-xs text-slate-400">Interviewer: {interview.interviewerName}</p>
          </div>
        </div>

        {/* Progress & Pacing */}
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2 text-slate-300 text-xs">
            <Clock className="w-4 h-4 text-indigo-400" />
            <span className="font-mono font-semibold text-white">{formatTime(elapsedSeconds)}</span>
            <span className="text-slate-500 hidden sm:inline">(Rec. 2-3 mins)</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                if (audioMuted) {
                  setAudioMuted(false);
                  speakCurrentQuestion();
                } else {
                  setAudioMuted(true);
                  SpeechService.stopSpeaking();
                  setIsAiSpeaking(false);
                }
              }}
              title={audioMuted ? "Unmute AI Voice" : "Mute AI Voice"}
              className={`p-2 rounded-xl border transition ${
                audioMuted 
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-400' 
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              {audioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setCameraActive(!cameraActive)}
              title={cameraActive ? "Turn Off Camera" : "Enable Webcam Preview"}
              className={`p-2 rounded-xl border transition ${
                cameraActive 
                  ? 'bg-sky-500/20 border-sky-500/40 text-sky-300' 
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              {cameraActive ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            </button>

            <button
              onClick={handleNext}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition"
            >
              <span>{currentIdx === interview.questions.length - 1 ? 'Wrap Up' : 'Skip / Next'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Interviewer + Candidate Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Interviewer & Question (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* AI Interviewer Card */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 shadow-xl p-5">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center font-bold text-white shadow-md shadow-indigo-500/30 text-lg">
                    {interview.interviewerName.charAt(0)}
                  </div>
                  {isAiSpeaking && (
                    <span className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
                    </span>
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-white text-base leading-tight">{interview.interviewerName}</h3>
                  <div className="flex items-center space-x-1.5 text-xs text-slate-400">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>AI Lead Interviewer</span>
                  </div>
                </div>
              </div>

              {/* Replay audio button */}
              <button
                onClick={speakCurrentQuestion}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-medium transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Replay Question</span>
              </button>
            </div>

            {/* Speaking audio visualizer bar */}
            {isAiSpeaking && (
              <div className="flex items-center justify-center space-x-1 py-3">
                {[12, 24, 16, 28, 20, 14, 26, 18, 22].map((height, i) => (
                  <div
                    key={i}
                    style={{ height: `${height}px` }}
                    className="w-1 bg-gradient-to-t from-indigo-500 to-sky-400 rounded-full animate-pulse"
                  />
                ))}
                <span className="text-xs text-indigo-300 font-medium ml-2">Speaking aloud...</span>
              </div>
            )}

            {/* Question Text Box */}
            <div className="mt-4 p-4 rounded-xl bg-slate-950/70 border border-slate-800/80">
              <div className="flex items-center justify-between mb-2">
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md uppercase tracking-wider ${
                  currentQuestion?.category === 'CODING' 
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : currentQuestion?.category === 'BEHAVIORAL'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                }`}>
                  {currentQuestion?.category}
                </span>

                <button
                  onClick={() => setShowExpectedHints(!showExpectedHints)}
                  className="flex items-center space-x-1 text-xs text-slate-400 hover:text-slate-200 transition"
                >
                  <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                  <span>{showExpectedHints ? 'Hide Hints' : 'View Key Concepts'}</span>
                </button>
              </div>

              <p className="text-white text-base sm:text-lg font-medium leading-relaxed">
                "{currentQuestion?.questionText}"
              </p>

              {/* Collapsible fresher coaching hints */}
              {showExpectedHints && currentQuestion?.expectedTopics && (
                <div className="mt-3 p-3 rounded-lg bg-indigo-950/40 border border-indigo-500/20 text-xs text-indigo-200 space-y-1">
                  <div className="font-semibold text-indigo-300 flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Expected Topics / Keywords for Freshers:</span>
                  </div>
                  <p className="text-slate-300 leading-normal">{currentQuestion.expectedTopics}</p>
                </div>
              )}
            </div>

            {/* Candidate Webcam / Audio Tile */}
            <div className="mt-4 relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800 aspect-video flex items-center justify-center">
              {cameraActive ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover transform -scale-x-100"
                />
              ) : (
                <div className="text-center p-6 space-y-2">
                  <div className="w-16 h-16 rounded-full bg-slate-800 mx-auto flex items-center justify-center text-slate-400">
                    <Eye className="w-7 h-7 text-slate-500" />
                  </div>
                  <p className="text-xs font-medium text-slate-300">Candidate Video Preview</p>
                  <p className="text-[11px] text-slate-500">Camera preview helps practice eye contact & posture</p>
                  <button
                    onClick={() => setCameraActive(true)}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition border border-slate-700"
                  >
                    <Video className="w-3.5 h-3.5 text-sky-400" />
                    <span>Enable Webcam</span>
                  </button>
                </div>
              )}

              {/* Status overlay */}
              <div className="absolute top-2 left-2 flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-black/60 backdrop-blur-md text-slate-300 border border-white/10">
                  {interview.userName}
                </span>
                {isRecording && (
                  <span className="flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/80 text-white animate-pulse">
                    <Mic className="w-2.5 h-2.5" />
                    <span>Listening</span>
                  </span>
                )}
              </div>
            </div>

          </div>

        </div>

        {/* Right Column: Candidate Answer, Voice, Code Editor & Evaluation (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Answer Workspace Card */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden flex flex-col min-h-[480px]">
            
            {/* Answer Mode Tabs */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setActiveInputTab('verbal')}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                    activeInputTab === 'verbal'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>Voice & Verbal Answer</span>
                </button>

                <button
                  onClick={() => setActiveInputTab('code')}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                    activeInputTab === 'code'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Code className="w-3.5 h-3.5 text-amber-400" />
                  <span>Code Scratchpad</span>
                </button>

                {currentQuestion?.category === 'BEHAVIORAL' && (
                  <button
                    onClick={() => setShowStarHelper(!showStarHelper)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30 hover:bg-purple-500/30 transition"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>STAR Method Helper</span>
                  </button>
                )}
              </div>

              {/* Speech Toggle Button */}
              <button
                onClick={toggleRecording}
                className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-xl font-bold text-xs transition shadow-md ${
                  isRecording
                    ? 'bg-rose-600 text-white animate-pulse shadow-rose-500/30'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-500/20'
                }`}
              >
                {isRecording ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                <span>{isRecording ? 'Stop Recording' : 'Speak Answer'}</span>
              </button>
            </div>

            {/* STAR Method Drawer */}
            {showStarHelper && (
              <div className="p-4 bg-purple-950/30 border-b border-purple-500/20 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                  <span className="flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>STAR Behavioral Answer Builder for Freshers:</span>
                  </span>
                  <button
                    onClick={() => setShowStarHelper(false)}
                    className="text-purple-400 hover:text-purple-200 text-[11px]"
                  >
                    Close
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-purple-300 font-semibold mb-1 block">1. Situation (Context)</label>
                    <textarea
                      rows={2}
                      value={starS}
                      onChange={e => setStarS(e.target.value)}
                      placeholder="During our 3rd-year semester project..."
                      className="w-full p-2 bg-slate-950/80 border border-purple-500/30 rounded-lg text-white text-xs placeholder-slate-500"
                    />
                  </div>
                  <div>
                    <label className="text-purple-300 font-semibold mb-1 block">2. Task (Your Role)</label>
                    <textarea
                      rows={2}
                      value={starT}
                      onChange={e => setStarT(e.target.value)}
                      placeholder="My responsibility was to fix latency..."
                      className="w-full p-2 bg-slate-950/80 border border-purple-500/30 rounded-lg text-white text-xs placeholder-slate-500"
                    />
                  </div>
                  <div>
                    <label className="text-purple-300 font-semibold mb-1 block">3. Action (Concrete Steps)</label>
                    <textarea
                      rows={2}
                      value={starA}
                      onChange={e => setStarA(e.target.value)}
                      placeholder="I used Wireshark, discovered connection leaks..."
                      className="w-full p-2 bg-slate-950/80 border border-purple-500/30 rounded-lg text-white text-xs placeholder-slate-500"
                    />
                  </div>
                  <div>
                    <label className="text-purple-300 font-semibold mb-1 block">4. Result (Impact & Learning)</label>
                    <textarea
                      rows={2}
                      value={starR}
                      onChange={e => setStarR(e.target.value)}
                      placeholder="Response time dropped 60%, received grade A..."
                      className="w-full p-2 bg-slate-950/80 border border-purple-500/30 rounded-lg text-white text-xs placeholder-slate-500"
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={handleApplyStar}
                    className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-lg transition"
                  >
                    Apply STAR Template into Answer
                  </button>
                </div>
              </div>
            )}

            {/* Input Workspace Body */}
            <div className="flex-1 p-4 flex flex-col">
              {activeInputTab === 'verbal' ? (
                <div className="flex-1 flex flex-col space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>
                      {isRecording ? '🔴 Listening to your voice... Speak clearly' : 'Type or speak your answer aloud:'}
                    </span>
                    <span>{candidateAnswer.split(/\s+/).filter(Boolean).length} words</span>
                  </div>

                  <textarea
                    value={candidateAnswer}
                    onChange={(e) => setCandidateAnswer(e.target.value)}
                    placeholder={
                      isRecording
                        ? "Transcribing your speech in real time..."
                        : "Click 'Speak Answer' to speak using microphone, or type your response here directly. Explain your thought process, trade-offs, and examples..."
                    }
                    className="flex-1 w-full p-4 bg-slate-950/60 border border-slate-800 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none font-normal leading-relaxed min-h-[220px]"
                  />
                </div>
              ) : (
                <div className="flex-1 flex flex-col space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-mono text-amber-300">Code Editor / Solution Scratchpad</span>
                    <button
                      onClick={() => setCodeSnippet(currentQuestion?.starterCode || '')}
                      className="text-slate-400 hover:text-white"
                    >
                      Reset Template
                    </button>
                  </div>
                  <textarea
                    value={codeSnippet}
                    onChange={(e) => setCodeSnippet(e.target.value)}
                    placeholder="// Write your code or pseudo-code implementation here..."
                    className="flex-1 w-full p-4 bg-slate-950 border border-slate-800 rounded-xl text-emerald-300 font-mono text-xs focus:outline-none focus:border-indigo-500 resize-none min-h-[220px]"
                  />
                </div>
              )}

              {/* Bottom Actions Bar */}
              <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-400">
                  {currentEvaluation ? (
                    <span className="text-emerald-400 font-semibold flex items-center space-x-1">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Evaluated! Score: {currentEvaluation.overallScore}/100</span>
                    </span>
                  ) : (
                    <span>Ready for evaluation. Submit to receive instant AI coaching.</span>
                  )}
                </div>

                <div className="flex items-center space-x-3">
                  <button
                    onClick={handleSubmitAnswer}
                    disabled={isSubmitting || !candidateAnswer.trim() && !codeSnippet.trim()}
                    className="flex items-center space-x-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-indigo-600/20 transition hover:scale-[1.02]"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Analyzing Response...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-amber-300" />
                        <span>{currentEvaluation ? 'Re-Evaluate Answer' : 'Submit for AI Rubric'}</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleNext}
                    className="flex items-center space-x-1.5 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition hover:scale-[1.02]"
                  >
                    <span>{currentIdx === interview.questions.length - 1 ? 'Finish & Generate Report' : 'Next Question'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>

          </div>

          {/* Instant Evaluation Card (Appears immediately after submitting) */}
          {currentEvaluation && (
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-indigo-500/30 shadow-2xl space-y-4 animate-in fade-in duration-300">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center font-extrabold text-emerald-400 text-sm">
                    {currentEvaluation.overallScore}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">AI Evaluator Feedback</h4>
                    <p className="text-[11px] text-slate-400">Campus Placement Rubric (/100)</p>
                  </div>
                </div>

                <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                  currentEvaluation.hireRecommendation === 'STRONG_HIRE'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : currentEvaluation.hireRecommendation === 'HIRE'
                    ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}>
                  {currentEvaluation.hireRecommendation.replace('_', ' ')}
                </span>
              </div>

              {/* 4 Rubric Metric Pillars */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
                  <div className="text-[11px] text-slate-400">Technical Depth</div>
                  <div className="text-base font-extrabold text-indigo-400">{currentEvaluation.technicalScore} <span className="text-[10px] text-slate-500">/ 25</span></div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
                  <div className="text-[11px] text-slate-400">Communication</div>
                  <div className="text-base font-extrabold text-sky-400">{currentEvaluation.communicationScore} <span className="text-[10px] text-slate-500">/ 25</span></div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
                  <div className="text-[11px] text-slate-400">Structure / STAR</div>
                  <div className="text-base font-extrabold text-purple-400">{currentEvaluation.structureScore} <span className="text-[10px] text-slate-500">/ 25</span></div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
                  <div className="text-[11px] text-slate-400">Confidence</div>
                  <div className="text-base font-extrabold text-emerald-400">{currentEvaluation.confidenceScore} <span className="text-[10px] text-slate-500">/ 25</span></div>
                </div>
              </div>

              {/* Feedback notes */}
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
                {currentEvaluation.feedback}
              </p>

              {/* Strengths & Improvements */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="space-y-1.5 p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20">
                  <div className="font-semibold text-emerald-300 flex items-center space-x-1">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Key Strengths:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                    {currentEvaluation.strengths.map((str, i) => (
                      <li key={i}>{str}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-1.5 p-3 rounded-xl bg-amber-950/20 border border-amber-500/20">
                  <div className="font-semibold text-amber-300 flex items-center space-x-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>How to Improve:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                    {currentEvaluation.improvements.map((imp, i) => (
                      <li key={i}>{imp}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Model Answer Preview */}
              {currentEvaluation.modelAnswer && (
                <details className="text-xs group bg-slate-950/80 rounded-xl border border-slate-800 p-3 cursor-pointer">
                  <summary className="font-bold text-slate-200 flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Exemplary Model Answer (What Top Candidates Say)</span>
                  </summary>
                  <p className="mt-2 text-slate-300 leading-relaxed pt-2 border-t border-slate-800 text-[11px]">
                    {currentEvaluation.modelAnswer}
                  </p>
                </details>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
