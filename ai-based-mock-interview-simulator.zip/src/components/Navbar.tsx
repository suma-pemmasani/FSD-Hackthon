import React from 'react';
import { 
  Bot, 
  BookOpen, 
  BarChart3, 
  Code2, 
  Sparkles, 
  Zap, 
  User as UserIcon,
  Play
} from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  activeTab: 'simulator' | 'bank' | 'analytics' | 'backend' | 'flashcards';
  setActiveTab: (tab: 'simulator' | 'bank' | 'analytics' | 'backend' | 'flashcards') => void;
  onOpenSetup: () => void;
  currentUser: User | null;
  interviewActive: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenSetup,
  currentUser,
  interviewActive
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Identity */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('simulator')}>
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-sky-500 shadow-lg shadow-indigo-500/25">
              <Bot className="w-5 h-5 text-white" />
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-base tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
                  InterviewPro AI
                </span>
                <span className="px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full">
                  Fresher Suite
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">AI-Based Mock Interview Simulator</p>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'simulator'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Mock Simulator</span>
              {interviewActive && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('bank')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'bank'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Question Bank</span>
            </button>

            <button
              onClick={() => setActiveTab('flashcards')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'flashcards'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Zap className="w-4 h-4 text-yellow-400" />
              <span>Quick Flashcards</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'analytics'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Analytics & History</span>
            </button>

            <button
              onClick={() => setActiveTab('backend')}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'backend'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Code2 className="w-4 h-4 text-emerald-400" />
              <span>Spring Boot Source</span>
            </button>
          </nav>

          {/* Right Action buttons */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onOpenSetup}
              className="flex items-center space-x-2 px-3.5 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-md shadow-emerald-500/20 transition-all hover:scale-[1.02]"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{interviewActive ? 'New Interview' : 'Start Mock'}</span>
            </button>

            {currentUser && (
              <div 
                onClick={onOpenSetup}
                title={`Profile: ${currentUser.name} (${currentUser.college || 'Fresher'})`}
                className="hidden sm:flex items-center space-x-2 py-1.5 px-3 rounded-lg bg-slate-800/80 border border-slate-700 text-xs text-slate-300 cursor-pointer hover:bg-slate-800 transition"
              >
                <div className="w-5 h-5 rounded-full bg-indigo-500/30 text-indigo-300 flex items-center justify-center font-bold text-[10px]">
                  {currentUser.name.charAt(0)}
                </div>
                <span className="truncate max-w-[100px]">{currentUser.name.split(' ')[0]}</span>
              </div>
            )}
          </div>

        </div>

        {/* Mobile Submenu Bar */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800/80 text-xs">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-2 py-1 rounded ${activeTab === 'simulator' ? 'text-indigo-400 font-bold' : 'text-slate-400'}`}
          >
            Simulator
          </button>
          <button
            onClick={() => setActiveTab('bank')}
            className={`px-2 py-1 rounded ${activeTab === 'bank' ? 'text-indigo-400 font-bold' : 'text-slate-400'}`}
          >
            Q-Bank
          </button>
          <button
            onClick={() => setActiveTab('flashcards')}
            className={`px-2 py-1 rounded ${activeTab === 'flashcards' ? 'text-indigo-400 font-bold' : 'text-slate-400'}`}
          >
            Flashcards
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-2 py-1 rounded ${activeTab === 'analytics' ? 'text-indigo-400 font-bold' : 'text-slate-400'}`}
          >
            Stats
          </button>
          <button
            onClick={() => setActiveTab('backend')}
            className={`px-2 py-1 rounded ${activeTab === 'backend' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}
          >
            Spring Boot
          </button>
        </div>

      </div>
    </header>
  );
};
