import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  BookOpen, 
  Play, 
  Sparkles, 
  CheckCircle, 
  Layers, 
  Building, 
  Tag,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { QUESTION_BANK, BankQuestion } from '../data/questionBank';

interface BankProps {
  onPracticeQuestion: (question: BankQuestion) => void;
}

export const QuestionBankView: React.FC<BankProps> = ({ onPracticeQuestion }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [expandedId, setExpandedId] = useState<string | null>(QUESTION_BANK[0]?.id || null);

  const categories = ['ALL', 'Java / Backend', 'DSA / Coding', 'Frontend / React', 'DBMS / SQL', 'HR & Behavioral'];

  const filteredQuestions = useMemo(() => {
    return QUESTION_BANK.filter(q => {
      const matchesCategory = selectedCategory === 'ALL' || q.category === selectedCategory;
      const matchesSearch = 
        q.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.questionText.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.companyTags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase())) ||
        q.expectedKeywords.some(k => k.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [searchTerm, selectedCategory]);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center space-x-2 text-indigo-400 font-bold text-xs uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" />
            <span>High-Yield Placement Question Bank</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            Curated College Fresher Question Bank
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Master 50+ high-frequency questions asked in campus drives across Tier-1 Product firms and IT Service recruiters.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 font-semibold text-slate-200">
            {filteredQuestions.length} Questions Available
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by topic (e.g. HashMap, Two Sum, ACID, TCS, Google, STAR)..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          />
          <Search className="absolute left-3 top-3 w-4 h-4 text-slate-500 pointer-events-none" />
        </div>

        {/* Category Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Questions List */}
      <div className="space-y-4">
        {filteredQuestions.length === 0 ? (
          <div className="text-center py-12 bg-slate-900 rounded-2xl border border-slate-800 p-8 space-y-2">
            <BookOpen className="w-10 h-10 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">No questions match your query</h3>
            <p className="text-xs text-slate-400">Try searching for generic terms like "Java", "React", or "SQL".</p>
          </div>
        ) : (
          filteredQuestions.map((q) => {
            const isExpanded = expandedId === q.id;
            return (
              <div
                key={q.id}
                className="rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition overflow-hidden shadow-lg"
              >
                {/* Accordion Header */}
                <div
                  onClick={() => setExpandedId(isExpanded ? null : q.id)}
                  className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
                >
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        {q.category}
                      </span>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                        q.frequency === 'Crucial'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}>
                        {q.frequency} Frequency
                      </span>
                      <span className="text-xs text-slate-500">•</span>
                      <span className="text-xs text-slate-400 font-medium">Difficulty: {q.difficulty}</span>
                    </div>

                    <h3 className="text-base font-bold text-white hover:text-indigo-300 transition">
                      {q.title}
                    </h3>
                  </div>

                  <div className="flex items-center space-x-3 self-end sm:self-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPracticeQuestion(q);
                      }}
                      className="flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition hover:scale-105"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Practice in Simulator</span>
                    </button>

                    <div className="text-slate-400">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </div>
                </div>

                {/* Accordion Body */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-2 border-t border-slate-800 space-y-4 text-xs animate-in fade-in duration-200">
                    
                    {/* The Full Question */}
                    <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                      <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px] block mb-1">
                        Exact Interviewer Prompt:
                      </span>
                      <p className="text-white text-sm font-medium leading-relaxed">
                        "{q.questionText}"
                      </p>
                    </div>

                    {/* Target Companies & Keywords */}
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-slate-400 font-semibold flex items-center space-x-1">
                        <Building className="w-3.5 h-3.5 text-slate-500" />
                        <span>Asked at:</span>
                      </span>
                      {q.companyTags.map(tag => (
                        <span key={tag} className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700 text-[11px]">
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Model Answer */}
                    <div className="p-4 rounded-xl bg-indigo-950/20 border border-indigo-500/20 space-y-2">
                      <div className="font-bold text-indigo-300 flex items-center space-x-1.5">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>Ideal Answer for College Placement Rounds:</span>
                      </div>
                      <p className="text-slate-200 text-xs sm:text-sm leading-relaxed">
                        {q.modelAnswer}
                      </p>
                    </div>

                    {/* STAR Guide if applicable */}
                    {q.starGuide && (
                      <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/20 space-y-2">
                        <div className="font-bold text-purple-300 flex items-center space-x-1.5">
                          <Layers className="w-4 h-4 text-purple-400" />
                          <span>STAR Method Behavioral Breakdown:</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
                          <p><strong className="text-purple-300">Situation:</strong> {q.starGuide.situation}</p>
                          <p><strong className="text-purple-300">Task:</strong> {q.starGuide.task}</p>
                          <p><strong className="text-purple-300">Action:</strong> {q.starGuide.action}</p>
                          <p><strong className="text-purple-300">Result:</strong> {q.starGuide.result}</p>
                        </div>
                      </div>
                    )}

                    {/* Key Concepts */}
                    <div className="space-y-1.5">
                      <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px] block">
                        Core Placement Evaluation Criteria:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {q.keyConcepts.map((kc, i) => (
                          <span key={i} className="px-2.5 py-1 rounded-lg bg-slate-950 text-slate-300 border border-slate-800 flex items-center space-x-1 text-[11px]">
                            <CheckCircle className="w-3 h-3 text-emerald-400" />
                            <span>{kc}</span>
                          </span>
                        ))}
                      </div>
                    </div>

                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
