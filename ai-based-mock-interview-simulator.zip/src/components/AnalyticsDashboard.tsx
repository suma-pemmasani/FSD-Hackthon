import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Award, 
  Clock, 
  CheckCircle2, 
  UserCheck, 
  FileText, 
  ChevronRight, 
  Layers, 
  Sparkles,
  Play
} from 'lucide-react';
import { Interview, PlatformStats } from '../types';

interface AnalyticsProps {
  interviews: Interview[];
  stats: PlatformStats | null;
  onSelectInterview: (interview: Interview) => void;
  onNewInterview: () => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsProps> = ({
  interviews,
  stats,
  onSelectInterview,
  onNewInterview
}) => {
  const completedInterviews = interviews.filter(i => i.status === 'COMPLETED');
  const avgScore = completedInterviews.length > 0 
    ? Math.round(completedInterviews.reduce((acc, curr) => acc + (curr.overallScore || 0), 0) / completedInterviews.length)
    : 82;

  const hireCount = completedInterviews.filter(i => i.hireDecision === 'STRONG_HIRE' || i.hireDecision === 'HIRE').length;
  const candidateHireRate = completedInterviews.length > 0
    ? Math.round((hireCount / completedInterviews.length) * 100)
    : 75;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center space-x-2 text-indigo-400 font-bold text-xs uppercase tracking-wider mb-1">
            <BarChart3 className="w-4 h-4" />
            <span>Placement Readiness Dashboard</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            Performance Analytics & Practice Log
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track your progress across technical and behavioral dimensions to build interview confidence.
          </p>
        </div>

        <button
          onClick={onNewInterview}
          className="flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-emerald-500/20 transition hover:scale-105 self-start sm:self-center"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Start New Mock</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Interviews Taken</span>
            <FileText className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-3xl font-black text-white">{completedInterviews.length}</div>
          <div className="text-[11px] text-slate-400">Total mock rounds logged</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Average Score</span>
            <Award className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-black text-emerald-400">
            {avgScore} <span className="text-sm text-slate-500 font-semibold">/100</span>
          </div>
          <div className="text-[11px] text-slate-400">Campus benchmark: 72+</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Hire Verdict Rate</span>
            <CheckCircle2 className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-3xl font-black text-teal-300">{candidateHireRate}%</div>
          <div className="text-[11px] text-slate-400">Strong Hire / Hire outcomes</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Community Benchmark</span>
            <TrendingUp className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-3xl font-black text-sky-300">
            {stats?.totalInterviews ? `${stats.totalInterviews.toLocaleString()}+` : '2,840+'}
          </div>
          <div className="text-[11px] text-slate-400">College mocks evaluated</div>
        </div>

      </div>

      {/* Progress Dimensions & Campus Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Core Skill Readiness Meter */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5">
          <h2 className="text-base font-bold text-white flex items-center space-x-2">
            <Layers className="w-5 h-5 text-indigo-400" />
            <span>Core Skill Placement Readiness</span>
          </h2>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 font-semibold mb-1">
                <span>Java & Object-Oriented Fundamentals</span>
                <span className="text-indigo-400 font-bold">88% (Proficient)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2">
                <div className="bg-indigo-500 h-2 rounded-full" style={{ width: '88%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 font-semibold mb-1">
                <span>Data Structures & Time Complexity</span>
                <span className="text-sky-400 font-bold">82% (Strong)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2">
                <div className="bg-sky-500 h-2 rounded-full" style={{ width: '82%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 font-semibold mb-1">
                <span>Database Indexing & ACID Transactions</span>
                <span className="text-emerald-400 font-bold">78% (Competitive)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2">
                <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '78%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 font-semibold mb-1">
                <span>Behavioral STAR Method Articulation</span>
                <span className="text-purple-400 font-bold">85% (Proficient)</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{ width: '85%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Most Practiced Roles */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h2 className="text-base font-bold text-white flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>Campus Placement In-Demand Roles</span>
          </h2>
          <div className="space-y-3 text-xs">
            {[
              { role: 'Java Backend Developer (Spring Boot, Microservices)', count: '1,140 freshers', trend: '+28%' },
              { role: 'Software Engineer (General SDE-1 / Product)', count: '980 freshers', trend: '+19%' },
              { role: 'Frontend React Developer (SPA, Modern JS)', count: '640 freshers', trend: '+15%' },
              { role: 'HR & Behavioral Cultural Fit Round', count: '520 freshers', trend: '+12%' }
            ].map((item, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">{item.role}</div>
                  <div className="text-slate-500 text-[11px]">{item.count}</div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold text-[11px]">
                  {item.trend}
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Past Interview History Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl space-y-4 p-6">
        <h2 className="text-base font-bold text-white">Your Interview History & Session Reports</h2>

        {interviews.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs space-y-2">
            <p>No interview sessions conducted yet.</p>
            <button
              onClick={onNewInterview}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-semibold transition"
            >
              Start First Mock Session
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <th className="pb-3 px-3">Session</th>
                  <th className="pb-3 px-3">Target Role</th>
                  <th className="pb-3 px-3">Target Firm</th>
                  <th className="pb-3 px-3">Score</th>
                  <th className="pb-3 px-3">Verdict</th>
                  <th className="pb-3 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {interviews.map(session => (
                  <tr key={session.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-3 font-mono text-slate-400">#{session.id}</td>
                    <td className="py-3 px-3 font-semibold text-white">{session.role}</td>
                    <td className="py-3 px-3">{session.companyType}</td>
                    <td className="py-3 px-3">
                      <span className="font-extrabold text-emerald-400">
                        {session.overallScore > 0 ? `${session.overallScore}/100` : 'In Progress'}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        session.hireDecision === 'STRONG_HIRE'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : session.hireDecision === 'HIRE'
                          ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                          : session.hireDecision === 'LEAN_HIRE'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}>
                        {session.hireDecision?.replace('_', ' ') || session.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => onSelectInterview(session)}
                        className="inline-flex items-center space-x-1 px-3 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 font-semibold transition"
                      >
                        <span>View Scorecard</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
