import React, { useEffect } from 'react';
import { 
  Award, 
  CheckCircle, 
  AlertTriangle, 
  Sparkles, 
  Printer, 
  RotateCcw, 
  Code2, 
  BookOpen, 
  GraduationCap, 
  Layers, 
  TrendingUp, 
  FileCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Interview } from '../types';

interface ReportProps {
  interview: Interview;
  onRetake: () => void;
  onExploreBackend: () => void;
}

export const EvaluationReport: React.FC<ReportProps> = ({
  interview,
  onRetake,
  onExploreBackend
}) => {
  const isHire = interview.hireDecision === 'STRONG_HIRE' || interview.hireDecision === 'HIRE';

  useEffect(() => {
    if (isHire) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  }, [isHire]);

  // Compute aggregate rubric dimensions
  let totalTech = 0;
  let totalComm = 0;
  let totalStruct = 0;
  let totalConf = 0;
  let evaluatedQuestions = 0;

  interview.questions.forEach(q => {
    if (q.answer?.evaluation) {
      totalTech += q.answer.evaluation.technicalScore;
      totalComm += q.answer.evaluation.communicationScore;
      totalStruct += q.answer.evaluation.structureScore;
      totalConf += q.answer.evaluation.confidenceScore;
      evaluatedQuestions++;
    }
  });

  const avgTech = evaluatedQuestions > 0 ? Math.round(totalTech / evaluatedQuestions) : 20;
  const avgComm = evaluatedQuestions > 0 ? Math.round(totalComm / evaluatedQuestions) : 21;
  const avgStruct = evaluatedQuestions > 0 ? Math.round(totalStruct / evaluatedQuestions) : 19;
  const avgConf = evaluatedQuestions > 0 ? Math.round(totalConf / evaluatedQuestions) : 20;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 print:p-0">
      
      {/* Top Banner & Verdict Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/60 border border-slate-800 p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="space-y-3 text-center md:text-left">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              <Award className="w-3.5 h-3.5" />
              <span>Official Campus Placement Performance Scorecard</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Interview Evaluation Report
            </h1>

            <p className="text-sm text-slate-300 max-w-xl">
              Candidate: <strong className="text-white">{interview.userName}</strong> • Target Role: <strong className="text-indigo-300">{interview.role}</strong> ({interview.companyType})
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1 text-xs text-slate-400">
              <span>Date: {new Date(interview.completedAt || interview.createdAt).toLocaleDateString()}</span>
              <span>•</span>
              <span>Interviewer: {interview.interviewerName}</span>
              <span>•</span>
              <span>Questions Answered: {evaluatedQuestions} of {interview.questions.length}</span>
            </div>
          </div>

          {/* Score Ring / Hire Decision Badge */}
          <div className="flex flex-col items-center p-6 rounded-2xl bg-slate-950/80 border border-slate-800/90 text-center min-w-[220px]">
            <div className="text-xs uppercase tracking-widest font-bold text-slate-400 mb-1">
              Overall Score
            </div>
            <div className="text-5xl font-black bg-gradient-to-r from-emerald-400 via-teal-300 to-sky-400 bg-clip-text text-transparent">
              {interview.overallScore}
              <span className="text-xl text-slate-500 font-semibold">/100</span>
            </div>

            <div className="mt-3">
              <span className={`px-4 py-1.5 rounded-full text-xs font-extrabold uppercase tracking-wider shadow-sm ${
                interview.hireDecision === 'STRONG_HIRE'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : interview.hireDecision === 'HIRE'
                  ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40'
                  : interview.hireDecision === 'LEAN_HIRE'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
              }`}>
                {interview.hireDecision?.replace('_', ' ') || 'COMPLETED'}
              </span>
            </div>
          </div>

        </div>

        {/* Executive Summary */}
        {interview.summaryFeedback && (
          <div className="mt-6 p-4 rounded-2xl bg-slate-950/60 border border-slate-800 text-sm text-slate-200 leading-relaxed">
            <strong className="text-indigo-300 block mb-1">Interviewer Feedback Summary:</strong>
            {interview.summaryFeedback}
          </div>
        )}

        {/* Action Buttons (Hidden during printing) */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center space-x-3">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs sm:text-sm rounded-xl border border-slate-700 transition"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onExploreBackend}
              className="flex items-center space-x-2 px-4 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 font-semibold text-xs sm:text-sm rounded-xl border border-emerald-500/30 transition"
            >
              <Code2 className="w-4 h-4" />
              <span>View Spring Boot Source</span>
            </button>
          </div>

          <button
            onClick={onRetake}
            className="flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-indigo-600/20 transition hover:scale-[1.02]"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Practice Another Session</span>
          </button>
        </div>
      </div>

      {/* 4-Pillar Rubric Breakdown Grid */}
      <div>
        <h2 className="text-lg font-bold text-white mb-4 flex items-center space-x-2">
          <Layers className="w-5 h-5 text-indigo-400" />
          <span>Campus Recruitment 4-Dimension Rubric Breakdown</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400 font-semibold uppercase">
              <span>Technical Accuracy</span>
              <span className="text-indigo-400">{avgTech} / 25</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2">
              <div 
                className="bg-indigo-500 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${(avgTech / 25) * 100}%` }}
              />
            </div>
            <p className="text-xs text-slate-400 pt-1">
              Depth of core CS principles, memory models, runtime complexity, and edge case coverage.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400 font-semibold uppercase">
              <span>Communication Clarity</span>
              <span className="text-sky-400">{avgComm} / 25</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2">
              <div 
                className="bg-sky-500 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${(avgComm / 25) * 100}%` }}
              />
            </div>
            <p className="text-xs text-slate-400 pt-1">
              Articulation, concise explanations, avoiding filler words, and professional engineering vocabulary.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400 font-semibold uppercase">
              <span>Structure & Logic</span>
              <span className="text-purple-400">{avgStruct} / 25</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2">
              <div 
                className="bg-purple-500 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${(avgStruct / 25) * 100}%` }}
              />
            </div>
            <p className="text-xs text-slate-400 pt-1">
              Structured sequence, applying STAR framework on situational questions, and trade-off comparisons.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400 font-semibold uppercase">
              <span>Confidence & Poise</span>
              <span className="text-emerald-400">{avgConf} / 25</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2">
              <div 
                className="bg-emerald-500 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${(avgConf / 25) * 100}%` }}
              />
            </div>
            <p className="text-xs text-slate-400 pt-1">
              Confidence, handling pushback, steady pacing, and genuine curiosity for software engineering.
            </p>
          </div>

        </div>
      </div>

      {/* Fresher Preparation Roadmap */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <span>Recommended Fresher Study Roadmap & Placement Strategy</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
            <span className="font-bold text-indigo-300 uppercase tracking-wider block">1. Conceptual Foundations</span>
            <p className="text-slate-300 leading-relaxed">
              Review internal data structure mechanics (e.g. HashMap bucket resizing, balanced Red-Black trees, and Java Garbage Collection generations).
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
            <span className="font-bold text-amber-300 uppercase tracking-wider block">2. Verbal Articulation</span>
            <p className="text-slate-300 leading-relaxed">
              Before writing code, state the brute-force time complexity first, then explain how HashMaps or two-pointer patterns reduce it to O(N).
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
            <span className="font-bold text-purple-300 uppercase tracking-wider block">3. STAR Storytelling</span>
            <p className="text-slate-300 leading-relaxed">
              Structure college project discussions around measurable outcomes (e.g., "reduced latency by 45%", "integrated 12 REST endpoints").
            </p>
          </div>
        </div>
      </div>

      {/* Question-by-Question Deep Dive */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center space-x-2">
          <FileCheck className="w-5 h-5 text-sky-400" />
          <span>Question-by-Question Deep Dive</span>
        </h2>

        {interview.questions.map((q, idx) => {
          const evalData = q.answer?.evaluation;
          return (
            <div
              key={q.id}
              className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-md"
            >
              {/* Question Header */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2.5">
                  <span className="flex items-center justify-center w-7 h-7 rounded-lg bg-indigo-600/20 text-indigo-400 font-bold text-xs border border-indigo-500/30">
                    Q{idx + 1}
                  </span>
                  <span className="text-xs font-semibold uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {q.category}
                  </span>
                </div>

                {evalData && (
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-slate-400">Score:</span>
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-extrabold text-xs border border-emerald-500/30">
                      {evalData.overallScore} / 100
                    </span>
                  </div>
                )}
              </div>

              {/* Question text */}
              <div className="text-white font-medium text-base">
                "{q.questionText}"
              </div>

              {/* Candidate's submitted answer */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Your Answer:
                </div>
                <p className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                  {q.answer?.candidateAnswer || <span className="text-slate-500 italic">No answer recorded.</span>}
                </p>

                {q.answer?.codeSnippet && (
                  <div className="mt-3 pt-3 border-t border-slate-800">
                    <div className="text-xs font-mono text-amber-300 mb-1">Code Implementation:</div>
                    <pre className="p-3 rounded-lg bg-slate-900 text-emerald-300 font-mono text-xs overflow-x-auto">
                      {q.answer.codeSnippet}
                    </pre>
                  </div>
                )}
              </div>

              {/* Evaluation insights */}
              {evalData && (
                <div className="space-y-3 pt-2">
                  <p className="text-xs text-slate-300 leading-relaxed bg-indigo-950/20 p-3 rounded-xl border border-indigo-500/20">
                    <strong className="text-indigo-300">Evaluator Note: </strong>
                    {evalData.feedback}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20 space-y-1">
                      <div className="font-semibold text-emerald-300 flex items-center space-x-1">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Strengths</span>
                      </div>
                      <ul className="list-disc list-inside text-slate-300 text-[11px] space-y-0.5">
                        {evalData.strengths.map((str, sIdx) => (
                          <li key={sIdx}>{str}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/20 space-y-1">
                      <div className="font-semibold text-amber-300 flex items-center space-x-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Areas to Elevate</span>
                      </div>
                      <ul className="list-disc list-inside text-slate-300 text-[11px] space-y-0.5">
                        {evalData.improvements.map((imp, iIdx) => (
                          <li key={iIdx}>{imp}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Model Answer Drawer */}
                  <details className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs cursor-pointer">
                    <summary className="font-semibold text-slate-200 flex items-center space-x-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Exemplary Campus Placement Model Answer</span>
                    </summary>
                    <p className="mt-2 text-slate-300 leading-relaxed pt-2 border-t border-slate-800 text-[11px]">
                      {evalData.modelAnswer || q.sampleAnswer}
                    </p>
                  </details>
                </div>
              )}

            </div>
          );
        })}
      </div>

    </div>
  );
};
