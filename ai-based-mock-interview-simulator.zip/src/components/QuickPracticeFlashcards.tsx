import React, { useState } from 'react';
import { Zap, RotateCw, CheckCircle, HelpCircle, ChevronLeft, ChevronRight, Award } from 'lucide-react';

interface Flashcard {
  id: number;
  category: string;
  front: string;
  back: string;
  keyTakeaway: string;
}

const CARDS: Flashcard[] = [
  {
    id: 1,
    category: 'Java Fundamentals',
    front: 'Why is String immutable in Java?',
    back: '1. Security: Sensitive data like passwords, network connections, and DB URLs cannot be altered after validation.\n2. Thread-Safety: Multiple threads can share strings without synchronization.\n3. String Constant Pool (SCP): Allows JVM to cache identical string literals, saving substantial heap memory.\n4. Hash Code Caching: hashCode is computed once and cached, making Strings ultra-fast keys in HashMaps.',
    keyTakeaway: 'Security + Thread-Safety + String Constant Pool Memory Savings.'
  },
  {
    id: 2,
    category: 'Spring Boot & JPA',
    front: 'What is the difference between @Component, @Service, and @Repository in Spring Boot?',
    back: '@Component is the generic stereotype annotation for any Spring-managed bean.\n\n@Service is a specialization of @Component indicating that the class provides business logic / service facade.\n\n@Repository is also a specialization of @Component, but it adds automatic persistence exception translation (translating vendor-specific SQL exceptions into Spring DataAccessException hierarchy).',
    keyTakeaway: '@Repository provides automatic database exception translation.'
  },
  {
    id: 3,
    category: 'Data Structures & Algorithms',
    front: "What is Floyd's Cycle-Finding Algorithm (Tortoise and Hare)?",
    back: "Uses two pointers: 'slow' advances 1 step and 'fast' advances 2 steps.\n- If fast reaches null: No cycle exists.\n- If slow and fast collide at the same node: A cycle is guaranteed.\n- Time Complexity: O(N)\n- Auxiliary Space Complexity: O(1) without requiring a HashSet.",
    keyTakeaway: 'Two pointers moving at speeds 1 and 2 detect linked list loops in O(1) space.'
  },
  {
    id: 4,
    category: 'React & Frontend',
    front: 'Why is using array index as key prop in React lists bad?',
    back: 'If list items are inserted at the beginning, deleted, or reordered, array indices change. React relies on keys to preserve component state across re-renders. Mismatched indices can lead to form inputs retaining incorrect text, animation glitches, and unnecessary DOM destruction and re-mounting.',
    keyTakeaway: 'Always use unique, stable IDs (like user.id) as React list keys.'
  },
  {
    id: 5,
    category: 'DBMS & SQL',
    front: 'Explain the difference between Clustered and Non-Clustered Indexes.',
    back: 'Clustered Index: Dictates the physical storage order of rows in the table. Each table can have only ONE clustered index (usually the Primary Key).\n\nNon-Clustered Index: Stored in a separate structure from the data rows. Contains key values and pointers (RowIDs or clustered index keys) back to the actual data. A table can have multiple non-clustered indexes.',
    keyTakeaway: 'Clustered index physically sorts data; Non-clustered index is an index booklet with pointers.'
  },
  {
    id: 6,
    category: 'Behavioral & HR',
    front: 'What is the STAR Method for behavioral interview questions?',
    back: 'Situation: Set the context (class project, hackathon, role, deadline).\nTask: Define what your specific challenge or deliverable was.\nAction: Describe the concrete engineering steps YOU took to solve it.\nResult: Conclude with quantifiable impact (reduced latency by 40%, scored grade A, zero bugs in demo).',
    keyTakeaway: 'Situation → Task → Action → Result. Focus 60% of your time on Action & Result.'
  }
];

export const QuickPracticeFlashcards: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [masteredIds, setMasteredIds] = useState<number[]>([]);

  const card = CARDS[currentIdx];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIdx(prev => (prev + 1) % CARDS.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIdx(prev => (prev - 1 + CARDS.length) % CARDS.length);
  };

  const toggleMastered = (id: number) => {
    if (masteredIds.includes(id)) {
      setMasteredIds(masteredIds.filter(i => i !== id));
    } else {
      setMasteredIds([...masteredIds, id]);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-yellow-400 font-bold text-xs uppercase tracking-wider mb-1">
            <Zap className="w-4 h-4" />
            <span>Pre-Interview Warmup Drill</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            Rapid Revision Flashcards
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Quick 5-minute memory refresh before stepping into your campus technical round.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 font-semibold text-emerald-400">
            {masteredIds.length} / {CARDS.length} Mastered
          </span>
        </div>
      </div>

      {/* Main Flashcard Card */}
      <div className="relative">
        <div
          onClick={() => setIsFlipped(!isFlipped)}
          className={`min-h-[320px] p-8 rounded-3xl border transition-all duration-300 cursor-pointer shadow-2xl flex flex-col justify-between select-none ${
            isFlipped
              ? 'bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 border-indigo-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          {/* Card Top */}
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-slate-800 text-indigo-300 border border-slate-700">
              {card.category}
            </span>
            <div className="flex items-center space-x-2 text-xs text-slate-400">
              <RotateCw className="w-3.5 h-3.5" />
              <span>{isFlipped ? 'Click to show Question' : 'Click to Reveal Answer'}</span>
            </div>
          </div>

          {/* Card Content */}
          <div className="my-6">
            {!isFlipped ? (
              <div className="space-y-3">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-widest">Question:</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-snug">
                  {card.front}
                </h2>
              </div>
            ) : (
              <div className="space-y-3 animate-in fade-in duration-200">
                <span className="text-xs font-semibold text-emerald-400 uppercase tracking-widest">Model Explanation:</span>
                <p className="text-sm sm:text-base text-slate-200 whitespace-pre-line leading-relaxed">
                  {card.back}
                </p>
                <div className="pt-2 text-xs text-indigo-300 font-semibold">
                  💡 Key Takeaway: {card.keyTakeaway}
                </div>
              </div>
            )}
          </div>

          {/* Card Bottom Progress */}
          <div className="flex items-center justify-between text-xs text-slate-500 pt-4 border-t border-slate-800/80">
            <span>Card {currentIdx + 1} of {CARDS.length}</span>
            <span className="text-indigo-400 font-medium">Click card anywhere to flip</span>
          </div>
        </div>
      </div>

      {/* Navigation & Mastery Controls */}
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={handlePrev}
          className="flex items-center space-x-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs sm:text-sm rounded-xl border border-slate-700 transition"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>

        <button
          onClick={() => toggleMastered(card.id)}
          className={`flex items-center space-x-2 px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
            masteredIds.includes(card.id)
              ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
              : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
          }`}
        >
          <CheckCircle className={`w-4 h-4 ${masteredIds.includes(card.id) ? 'text-emerald-400' : 'text-slate-500'}`} />
          <span>{masteredIds.includes(card.id) ? 'Mastered!' : 'Mark as Mastered'}</span>
        </button>

        <button
          onClick={handleNext}
          className="flex items-center space-x-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs sm:text-sm rounded-xl transition"
        >
          <span>Next</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
