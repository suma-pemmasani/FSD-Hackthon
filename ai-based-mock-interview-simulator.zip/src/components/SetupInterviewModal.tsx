import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  GraduationCap, 
  Building2, 
  UserCheck, 
  Clock, 
  Mic, 
  Video, 
  CheckCircle2, 
  ChevronRight,
  Layers,
  Award
} from 'lucide-react';
import { InterviewSetupOptions } from '../types';

interface SetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStart: (options: InterviewSetupOptions) => Promise<void>;
  isLoading: boolean;
  initialOptions?: Partial<InterviewSetupOptions>;
}

const ROLES = [
  { id: 'Java Backend Developer', name: 'Java Backend Developer', desc: 'Spring Boot, Collections, Multi-threading, JPA, REST, SQL' },
  { id: 'Software Engineer', name: 'Software Engineer (General)', desc: 'DSA, OOPs, DBMS, OS, Computer Networks, System Basics' },
  { id: 'Frontend React Developer', name: 'Frontend React Developer', desc: 'React.js, JavaScript (ES6+), State, Hooks, CSS, Web Vitals' },
  { id: 'HR & Behavioral', name: 'HR & Behavioral Round', desc: 'STAR Framework, Project crises, Teamwork, Motivation' }
];

const COMPANY_TYPES = [
  { id: 'Product Tech / FAANG', name: 'Tier-1 Product / FAANG', desc: 'High bar on DSA efficiency, edge cases & deep internal mechanics' },
  { id: 'High-Growth Tech Startup', name: 'High-Growth Startup', desc: 'Hands-on practical development, quick problem solving & hustle' },
  { id: 'IT Services & Mass Recruiter', name: 'IT Services (TCS/Infy/Wipro)', desc: 'Fundamental OOPs concepts, basic coding, database queries & attitude' },
  { id: 'FinTech & Banking Tech', name: 'FinTech / High-Reliability', desc: 'Transactions, ACID compliance, precision, and security basics' }
];

const PERSONAS = [
  { id: 'Alex', name: 'Alex', title: 'Senior Tech Lead', tone: 'Balanced & analytical, focuses on tradeoffs' },
  { id: 'Priya', name: 'Priya', title: 'Engineering Manager', tone: 'Warm, encouraging, evaluates problem-solving thought process' },
  { id: 'David', name: 'David', title: 'Staff Systems Architect', tone: 'Deep technical rigor, probes corner cases & complexities' },
  { id: 'Sarah', name: 'Sarah', title: 'HR & Talent Partner', tone: 'Culture fit, STAR storytelling, collegiate growth & drive' }
];

export const SetupInterviewModal: React.FC<SetupModalProps> = ({
  isOpen,
  onClose,
  onStart,
  isLoading,
  initialOptions
}) => {
  const [name, setName] = useState(initialOptions?.name || 'Aarav Sharma');
  const [email, setEmail] = useState(initialOptions?.email || 'aarav.sharma@college.edu');
  const [college, setCollege] = useState(initialOptions?.college || 'National Institute of Technology');
  const [graduationYear, setGraduationYear] = useState(initialOptions?.graduationYear || 2026);
  const [role, setRole] = useState(initialOptions?.role || 'Java Backend Developer');
  const [companyType, setCompanyType] = useState(initialOptions?.companyType || 'Product Tech / FAANG');
  const [difficulty, setDifficulty] = useState(initialOptions?.difficulty || 'FRESHER');
  const [interviewerName, setInterviewerName] = useState(initialOptions?.interviewerName || 'Alex');
  const [totalQuestions, setTotalQuestions] = useState(initialOptions?.totalQuestions || 5);
  const [mode, setMode] = useState(initialOptions?.mode || 'MIXED');
  const [step, setStep] = useState<1 | 2>(1);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onStart({
      name: name.trim() || 'Candidate',
      email: email.trim() || 'candidate@college.edu',
      college: college.trim() || 'Engineering College',
      graduationYear: Number(graduationYear),
      role,
      companyType,
      difficulty,
      interviewerName,
      totalQuestions: Number(totalQuestions),
      mode,
      customTopics: []
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100 overflow-hidden my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Configure Your Mock Interview</h2>
              <p className="text-xs text-slate-400">Tailored simulation designed for college students & freshers</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isLoading}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          
          {step === 1 ? (
            <div className="space-y-5 animate-in fade-in duration-200">
              
              {/* Profile Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Candidate Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Aarav Sharma"
                    className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    College / University
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={college}
                      onChange={(e) => setCollege(e.target.value)}
                      placeholder="e.g. National Institute of Tech"
                      className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    />
                    <GraduationCap className="absolute right-3 top-2.5 w-4 h-4 text-slate-500 pointer-events-none" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@college.edu"
                    className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Graduation Batch
                  </label>
                  <select
                    value={graduationYear}
                    onChange={(e) => setGraduationYear(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value={2027}>Batch 2027 (Pre-Final Year)</option>
                    <option value={2026}>Batch 2026 (Final Year / Passing Out)</option>
                    <option value={2025}>Batch 2025 (Fresh Graduate)</option>
                    <option value={2024}>Batch 2024 (Early Career / 0-1 yr)</option>
                  </select>
                </div>
              </div>

              {/* Role Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Select Target Placement Role
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {ROLES.map((r) => {
                    const isSelected = role === r.id;
                    return (
                      <div
                        key={r.id}
                        onClick={() => setRole(r.id)}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-indigo-600/15 border-indigo-500 ring-1 ring-indigo-500'
                            : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`text-sm font-semibold ${isSelected ? 'text-indigo-300' : 'text-slate-200'}`}>
                            {r.name}
                          </span>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-indigo-400" />}
                        </div>
                        <p className="text-xs text-slate-400 mt-1 line-clamp-2">{r.desc}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Company Profile Target */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Target Company Type
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {COMPANY_TYPES.map((c) => {
                    const isSelected = companyType === c.id;
                    return (
                      <div
                        key={c.id}
                        onClick={() => setCompanyType(c.id)}
                        className={`p-3 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-emerald-600/15 border-emerald-500 ring-1 ring-emerald-500'
                            : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-semibold ${isSelected ? 'text-emerald-300' : 'text-slate-200'}`}>
                            {c.name}
                          </span>
                          {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{c.desc}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="flex items-center space-x-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm rounded-xl transition"
                >
                  <span>Next: Interview Persona & Format</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          ) : (
            <div className="space-y-5 animate-in fade-in duration-200">
              
              {/* Persona Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Choose AI Interviewer Persona
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {PERSONAS.map((p) => {
                    const isSelected = interviewerName === p.id;
                    return (
                      <div
                        key={p.id}
                        onClick={() => setInterviewerName(p.id)}
                        className={`p-3 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-indigo-600/20 border-indigo-500 ring-1 ring-indigo-500'
                            : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                            isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-300'
                          }`}>
                            {p.name.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center space-x-1.5">
                              <span className="text-sm font-semibold text-white">{p.name}</span>
                              <span className="text-[11px] text-slate-400 font-medium">({p.title})</span>
                            </div>
                            <p className="text-[11px] text-slate-400 leading-tight">{p.tone}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Number of Questions & Mode */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Round Length (Questions)
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { val: 3, label: '3 Qs', sub: 'Quick Drill (10 min)' },
                      { val: 5, label: '5 Qs', sub: 'Standard (20 min)' },
                      { val: 7, label: '7 Qs', sub: 'In-Depth (30 min)' }
                    ].map((item) => (
                      <button
                        type="button"
                        key={item.val}
                        onClick={() => setTotalQuestions(item.val)}
                        className={`p-2.5 rounded-xl border text-center transition ${
                          totalQuestions === item.val
                            ? 'bg-indigo-600 text-white border-indigo-500 shadow'
                            : 'bg-slate-950/50 border-slate-800 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div className="font-bold text-sm">{item.label}</div>
                        <div className="text-[10px] text-slate-400">{item.sub}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Round Style
                  </label>
                  <select
                    value={mode}
                    onChange={(e) => setMode(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-slate-700/80 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="MIXED">Mixed (Technical Q&A + Coding + Behavioral)</option>
                    <option value="CODING">Coding & Algorithms Focus</option>
                    <option value="TECHNICAL">Deep CS Fundamentals & Frameworks</option>
                    <option value="BEHAVIORAL">HR & Behavioral (STAR Method)</option>
                  </select>
                </div>
              </div>

              {/* Feature Highlights for College Freshers */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <div className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>Campus Placement Simulator Features Included:</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                  <div className="flex items-center space-x-1.5">
                    <Mic className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Real-time voice speech recognition</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Video className="w-3.5 h-3.5 text-sky-400" />
                    <span>Live webcam face & posture frame</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Layers className="w-3.5 h-3.5 text-emerald-400" />
                    <span>4-dimension rubric scoring (/100)</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    <span>Model ideal answers for freshers</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  disabled={isLoading}
                  className="px-4 py-2 text-sm text-slate-400 hover:text-white transition"
                >
                  Back to Profile
                </button>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex items-center space-x-2 px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-500/20 disabled:opacity-50 transition hover:scale-[1.02]"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Preparing AI Questions...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Enter Interview Room</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          )}

        </form>

      </div>
    </div>
  );
};
