import React, { useState, useEffect } from 'react';
import { 
  Code2, 
  Folder, 
  FileCode, 
  Copy, 
  Check, 
  Layers, 
  Database, 
  Send, 
  ExternalLink,
  Terminal,
  Cpu,
  Server
} from 'lucide-react';
import { SpringBootFile } from '../types';
import { apiService } from '../services/api';

export const SpringBootExplorer: React.FC = () => {
  const [files, setFiles] = useState<SpringBootFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<SpringBootFile | null>(null);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'architecture' | 'code' | 'api-docs'>('architecture');
  const [apiEndpoint, setApiEndpoint] = useState('/api/interviews');
  const [apiMethod, setApiMethod] = useState<'GET' | 'POST'>('POST');
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [isCallingApi, setIsCallingApi] = useState(false);

  useEffect(() => {
    apiService.getBackendFiles()
      .then(res => {
        if (res.files && res.files.length > 0) {
          setFiles(res.files);
          setSelectedFile(res.files.find(f => f.name === 'InterviewController.java') || res.files[0]);
        }
      })
      .catch(err => console.warn('Could not load backend files:', err));
  }, []);

  const handleCopy = () => {
    if (selectedFile) {
      navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleTestApi = async () => {
    setIsCallingApi(true);
    setApiResponse(null);
    try {
      if (apiEndpoint === '/api/interviews' && apiMethod === 'POST') {
        const res = await fetch('/api/interviews', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: 1,
            role: 'Java Backend Developer',
            companyType: 'Product Tech / FAANG',
            difficulty: 'FRESHER',
            totalQuestions: 3
          })
        });
        const data = await res.json();
        setApiResponse(data);
      } else if (apiEndpoint === '/api/users' && apiMethod === 'POST') {
        const res = await fetch('/api/users', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: 'Pooja Verma',
            email: 'pooja.verma@college.edu',
            college: 'Delhi Technological University',
            graduationYear: 2026,
            targetRole: 'Java Backend Developer'
          })
        });
        const data = await res.json();
        setApiResponse(data);
      } else {
        const res = await fetch(apiEndpoint);
        const data = await res.json();
        setApiResponse(data);
      }
    } catch (e: any) {
      setApiResponse({ error: e.message || 'API request failed' });
    } finally {
      setIsCallingApi(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-emerald-400 font-bold text-xs uppercase tracking-wider mb-1">
            <Server className="w-4 h-4" />
            <span>Full-Stack Architecture & Code Viewer</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            Java 17 + Spring Boot + JPA / Hibernate Backend
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Production-style multi-tiered architecture following Controller → Service → Repository → Entity → MySQL / PostgreSQL.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center space-x-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'architecture' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Architecture
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'code' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Java Source Code
          </button>
          <button
            onClick={() => setActiveTab('api-docs')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'api-docs' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            REST API Tester
          </button>
        </div>
      </div>

      {/* Tab 1: Architecture Visualizer */}
      {activeTab === 'architecture' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <span>Full-Stack Architectural Flow</span>
            </h2>

            {/* Visual Diagram */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              
              {/* Layer 1 */}
              <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 space-y-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300">
                  Client Tier
                </span>
                <h3 className="font-bold text-sm text-white">React 19 + Vite</h3>
                <ul className="text-[11px] text-slate-400 space-y-1">
                  <li>• Speech Recognition</li>
                  <li>• Webcam Preview</li>
                  <li>• Real-time Rubrics</li>
                  <li>• REST Axios / Fetch</li>
                </ul>
              </div>

              {/* Layer 2 */}
              <div className="p-4 rounded-2xl bg-blue-950/30 border border-blue-500/30 space-y-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300">
                  Controller Tier
                </span>
                <h3 className="font-bold text-sm text-white">@RestController</h3>
                <ul className="text-[11px] text-slate-400 space-y-1">
                  <li>• InterviewController</li>
                  <li>• EvaluationController</li>
                  <li>• QuestionController</li>
                  <li>• UserController</li>
                </ul>
              </div>

              {/* Layer 3 */}
              <div className="p-4 rounded-2xl bg-sky-950/30 border border-sky-500/30 space-y-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300">
                  Service Tier
                </span>
                <h3 className="font-bold text-sm text-white">@Service Logic</h3>
                <ul className="text-[11px] text-slate-400 space-y-1">
                  <li>• InterviewService</li>
                  <li>• EvaluationService</li>
                  <li>• QuestionService</li>
                  <li>• Rubric Scoring Engine</li>
                </ul>
              </div>

              {/* Layer 4 */}
              <div className="p-4 rounded-2xl bg-teal-950/30 border border-teal-500/30 space-y-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-500/20 text-teal-300">
                  Persistence Tier
                </span>
                <h3 className="font-bold text-sm text-white">Spring Data JPA</h3>
                <ul className="text-[11px] text-slate-400 space-y-1">
                  <li>• JpaRepository&lt;T, ID&gt;</li>
                  <li>• Hibernate 6 ORM</li>
                  <li>• Entity Mappings</li>
                  <li>• DTO Validations</li>
                </ul>
              </div>

              {/* Layer 5 */}
              <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 space-y-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                  Database Tier
                </span>
                <h3 className="font-bold text-sm text-white">MySQL / Postgres</h3>
                <ul className="text-[11px] text-slate-400 space-y-1">
                  <li>• users table</li>
                  <li>• interviews table</li>
                  <li>• questions table</li>
                  <li>• evaluations table</li>
                </ul>
              </div>

            </div>

            {/* Quick Terminal Guide */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 font-mono text-xs text-slate-300">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                <Terminal className="w-4 h-4" />
                <span>Running the Spring Boot Application Locally with Maven:</span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl space-y-1.5 text-slate-200">
                <div className="text-slate-500"># 1. Navigate to the backend directory</div>
                <div>cd backend</div>
                <div className="text-slate-500 pt-1"># 2. Compile and run with in-memory H2 or MySQL</div>
                <div>mvn clean spring-boot:run</div>
                <div className="text-slate-500 pt-1"># 3. Access Swagger UI OpenAPI specification</div>
                <div className="text-indigo-400">http://localhost:8080/swagger-ui.html</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Code Explorer */}
      {activeTab === 'code' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* File Tree (4 Cols) */}
          <div className="lg:col-span-4 p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-300 uppercase tracking-wider pb-2 border-b border-slate-800">
              <Folder className="w-4 h-4 text-amber-400" />
              <span>Project Explorer (backend/)</span>
            </div>

            <div className="space-y-1 max-h-[500px] overflow-y-auto text-xs pr-1">
              {files.map((file) => {
                const isSelected = selectedFile?.path === file.path;
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-left transition ${
                      isSelected
                        ? 'bg-indigo-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : 'text-slate-500'}`} />
                    <span className="truncate">{file.path}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Code Viewer (8 Cols) */}
          <div className="lg:col-span-8 rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/90 border-b border-slate-800">
              <div className="flex items-center space-x-2 text-xs font-mono text-slate-300">
                <FileCode className="w-4 h-4 text-emerald-400" />
                <span>{selectedFile?.path || 'No file selected'}</span>
              </div>

              <button
                onClick={handleCopy}
                className="flex items-center space-x-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>
            </div>

            <pre className="p-4 overflow-x-auto text-slate-200 font-mono text-xs leading-relaxed max-h-[520px]">
              <code>{selectedFile?.content}</code>
            </pre>
          </div>

        </div>
      )}

      {/* Tab 3: REST API Tester */}
      {activeTab === 'api-docs' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6 shadow-xl">
          <div>
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <Server className="w-5 h-5 text-emerald-400" />
              <span>Interactive REST API Client (Swagger-Style)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Verify live API responses returned by the backend controllers.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <select
              value={`${apiMethod} ${apiEndpoint}`}
              onChange={(e) => {
                const [m, ep] = e.target.value.split(' ');
                setApiMethod(m as any);
                setApiEndpoint(ep);
              }}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="POST /api/interviews">POST /api/interviews (Create Interview)</option>
              <option value="POST /api/users">POST /api/users (Create User Profile)</option>
              <option value="GET /api/stats">GET /api/stats (Platform Statistics)</option>
              <option value="GET /api/backend/code">GET /api/backend/code (Get Source Files)</option>
            </select>

            <button
              onClick={handleTestApi}
              disabled={isCallingApi}
              className="flex items-center space-x-1.5 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isCallingApi ? 'Sending Request...' : 'Send Request'}</span>
            </button>
          </div>

          {/* Response Box */}
          {apiResponse && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>Response Status: 200 OK</span>
                <span>Content-Type: application/json</span>
              </div>
              <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-emerald-400 font-mono text-xs max-h-80 overflow-y-auto">
                {JSON.stringify(apiResponse, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
