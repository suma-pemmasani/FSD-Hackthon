import { Interview, Question, Evaluation, User, PlatformStats, SpringBootFile, InterviewSetupOptions } from '../types';

const BASE_URL = '/api';

export const apiService = {
  // User Management
  async getOrCreateUser(userData: {
    name: string;
    email: string;
    college?: string;
    graduationYear?: number;
    targetRole?: string;
    experienceLevel?: string;
  }): Promise<User> {
    const res = await fetch(`${BASE_URL}/users`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    if (!res.ok) throw new Error('Failed to create or fetch user profile');
    return res.json();
  },

  // Start Interview
  async startInterview(params: InterviewSetupOptions & { userId?: number }): Promise<Interview> {
    const res = await fetch(`${BASE_URL}/interviews`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) throw new Error('Failed to start interview session');
    return res.json();
  },

  // Get Interview Details
  async getInterview(interviewId: number): Promise<Interview> {
    const res = await fetch(`${BASE_URL}/interviews/${interviewId}`);
    if (!res.ok) throw new Error('Failed to load interview');
    return res.json();
  },

  // Evaluate Answer
  async evaluateAnswer(params: {
    questionId: number;
    candidateAnswer: string;
    codeSnippet?: string;
    durationSeconds?: number;
  }): Promise<Evaluation> {
    const res = await fetch(`${BASE_URL}/evaluations/evaluate-answer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) throw new Error('Failed to evaluate answer');
    return res.json();
  },

  // Finalize Interview
  async finalizeInterview(interviewId: number): Promise<Interview> {
    const res = await fetch(`${BASE_URL}/interviews/${interviewId}/finalize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    if (!res.ok) throw new Error('Failed to finalize interview report');
    return res.json();
  },

  // User History
  async getUserInterviews(userId: number): Promise<Interview[]> {
    const res = await fetch(`${BASE_URL}/interviews/user/${userId}`);
    if (!res.ok) throw new Error('Failed to fetch user interviews');
    return res.json();
  },

  // Platform Analytics
  async getStats(): Promise<PlatformStats> {
    const res = await fetch(`${BASE_URL}/stats`);
    if (!res.ok) throw new Error('Failed to fetch platform stats');
    return res.json();
  },

  // Spring Boot Source Files
  async getBackendFiles(): Promise<{ files: SpringBootFile[] }> {
    const res = await fetch(`${BASE_URL}/backend/code`);
    if (!res.ok) throw new Error('Failed to fetch backend files');
    return res.json();
  }
};
