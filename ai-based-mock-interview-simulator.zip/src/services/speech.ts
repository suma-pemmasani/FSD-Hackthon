// Speech Synthesis (TTS) & Web Speech Recognition (STT) helpers

interface SpeechRecognitionEvent {
  resultIndex: number;
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
      isFinal: boolean;
    };
    length: number;
  };
}

interface SpeechRecognitionErrorEvent {
  error: string;
  message?: string;
}

export class SpeechService {
  private static synth: SpeechSynthesis | null = typeof window !== 'undefined' ? window.speechSynthesis : null;
  private static recognition: any = null;
  private static isSpeakingFlag = false;

  // Speak text out loud using browser speech synthesis
  static speak(
    text: string,
    persona: string = 'Alex',
    onStart?: () => void,
    onEnd?: () => void
  ): boolean {
    if (!this.synth) return false;

    try {
      this.synth.cancel(); // Stop prior speech

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = persona === 'Priya' || persona === 'Sarah' ? 1.15 : 0.95;

      const voices = this.synth.getVoices();
      if (voices.length > 0) {
        // Find best matching voice
        let preferredVoice = voices.find(v => v.lang.startsWith('en') && (
          (persona === 'Priya' && (v.name.includes('India') || v.name.includes('Female'))) ||
          (persona === 'Sarah' && (v.name.includes('Female') || v.name.includes('Samantha') || v.name.includes('Google UK English Female'))) ||
          (persona === 'David' && (v.name.includes('Male') || v.name.includes('Daniel') || v.name.includes('Google UK English Male'))) ||
          (persona === 'Alex' && (v.name.includes('Natural') || v.name.includes('David') || v.name.includes('Google US English')))
        ));

        if (!preferredVoice) {
          preferredVoice = voices.find(v => v.lang.startsWith('en')) || voices[0];
        }

        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }
      }

      utterance.onstart = () => {
        this.isSpeakingFlag = true;
        onStart?.();
      };

      utterance.onend = () => {
        this.isSpeakingFlag = false;
        onEnd?.();
      };

      utterance.onerror = () => {
        this.isSpeakingFlag = false;
        onEnd?.();
      };

      this.synth.speak(utterance);
      return true;
    } catch (err) {
      console.warn('Speech synthesis error:', err);
      this.isSpeakingFlag = false;
      onEnd?.();
      return false;
    }
  }

  static stopSpeaking() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeakingFlag = false;
    }
  }

  static isSpeaking(): boolean {
    return this.isSpeakingFlag || (this.synth ? this.synth.speaking : false);
  }

  // Check if browser speech recognition is supported
  static isRecognitionSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }

  // Start continuous speech recognition for candidate answering
  static startListening(
    onResult: (transcript: string, isFinal: boolean) => void,
    onError: (error: string) => void,
    onEnd: () => void
  ): boolean {
    if (!this.isRecognitionSupported()) {
      onError('Speech Recognition is not supported in this browser. You can type your answers directly.');
      return false;
    }

    try {
      const SpeechRecognitionConstructor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      this.recognition = new SpeechRecognitionConstructor();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';

      this.recognition.onresult = (event: SpeechRecognitionEvent) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const item = event.results[i];
          if (item.isFinal) {
            finalTranscript += item[0].transcript + ' ';
          } else {
            interimTranscript += item[0].transcript;
          }
        }

        if (finalTranscript) {
          onResult(finalTranscript.trim(), true);
        } else if (interimTranscript) {
          onResult(interimTranscript.trim(), false);
        }
      };

      this.recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          onError('Microphone permission was denied. Please allow microphone access or type your answers.');
        } else if (event.error !== 'no-speech') {
          onError(`Speech recognition note: ${event.error}`);
        }
      };

      this.recognition.onend = () => {
        onEnd();
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      console.warn('Failed to start speech recognition:', err);
      onError(err.message || 'Microphone could not be started');
      return false;
    }
  }

  static stopListening() {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
      this.recognition = null;
    }
  }
}
