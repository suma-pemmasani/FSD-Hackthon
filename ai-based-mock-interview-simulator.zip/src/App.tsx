import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Play, 
  BookOpen, 
  Award, 
  Video, 
  Mic, 
  Code2, 
  Layers, 
  CheckCircle, 
  GraduationCap, 
  ArrowRight,
  TrendingUp,
  BarChart3,
  Zap,
  ShieldCheck,
  Server
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { SetupInterviewModal } from './components/SetupInterviewModal';
import { InterviewRoom } from './components/InterviewRoom';
import { EvaluationReport } from './components/EvaluationReport';
import { QuestionBankView } from './components/QuestionBankView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { SpringBootExplorer } from './components/SpringBootExplorer';
import { QuickPracticeFlashcards } from './components/QuickPracticeFlashcards';
import { Interview, User, PlatformStats, InterviewSetupOptions, Evaluation } from './types';
import { apiService } from './services/api';
import { BankQuestion } from './data/questionBank';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'bank' | 'analytics' | 'backend' | 'flashcards'>('simulator');
  const [currentUser, setCurrentUser] = useState<User | null>({
    id: 1,
    name: 'Aarav Sharma',
    email: 'aarav.sharma@college.edu',
    college: 'Indian Institute of Technology (BHU)',
    graduationYear: 2026,
    targetRole: 'Java Backend Developer',
    experienceLevel: 'FRESHER',
    createdAt: new Date().toISOString()
  });

  const [currentInterview, setCurrentInterview] = useState<Interview | null>(null);
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [isSetupOpen, setIsSetupOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [setupInitialOptions, setSetupInitialOptions] = useState<Partial<InterviewSetupOptions>>({});

  // Initial load
  useEffect(() => {
    // Fetch stats
    apiService.getStats()
      .then(res => setStats(res))
      .catch(e => console.warn('Could not load stats:', e));

    // Fetch user history if user exists
    if (currentUser?.id) {
      apiService.getUserInterviews(currentUser.id)
        .then(res => {
          if (Array.isArray(res)) setInterviews(res);
        })
        .catch(e => console.warn('Could not load interviews:', e));
    }
  }, [currentUser?.id]);

  // Start new interview
  const handleStartInterview = async (options: InterviewSetupOptions) => {
    setIsLoading(true);
    try {
      // 1. Create or ensure user exists
      const user = await apiService.getOrCreateUser({
        name: options.name,
        email: options.email,
        college: options.college,
        graduationYear: options.graduationYear,
        targetRole: options.role,
        experienceLevel: options.difficulty
      });
      setCurrentUser(user);

      // 2. Start Interview
      const interview = await apiService.startInterview({
        ...options,
        userId: user.id
      });

      setCurrentInterview(interview);
      setInterviews(prev => [interview, ...prev.filter(i => i.id !== interview.id)]);
      setIsSetupOpen(false);
      setActiveTab('simulator');
    } catch (err: any) {
      console.error('Failed to start interview:', err);
      alert('Could not start mock interview session. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Evaluate candidate answer
  const handleEvaluateAnswer = async (
    questionId: number,
    answerText: string,
    codeSnippet?: string,
    duration?: number
  ): Promise<Evaluation> => {
    setIsSubmitting(true);
    try {
      const evaluation = await apiService.evaluateAnswer({
        questionId,
        candidateAnswer: answerText,
        codeSnippet,
        durationSeconds: duration
      });

      // Update question in currentInterview
      if (currentInterview) {
        const updatedQuestions = currentInterview.questions.map(q => {
          if (q.id === questionId) {
            return {
              ...q,
              answer: {
                questionId,
                candidateAnswer: answerText,
                codeSnippet,
                durationSeconds: duration,
                evaluation
              }
            };
          }
          return q;
        });

        setCurrentInterview({
          ...currentInterview,
          questions: updatedQuestions
        });
      }

      return evaluation;
    } finally {
      setIsSubmitting(false);
    }
  };

  // Finalize interview
  const handleFinishInterview = async () => {
    if (!currentInterview) return;
    try {
      const finalized = await apiService.finalizeInterview(currentInterview.id);
      setCurrentInterview(finalized);
      setInterviews(prev => [finalized, ...prev.filter(i => i.id !== finalized.id)]);
    } catch (err) {
      console.error('Error finalizing interview:', err);
    }
  };

  // Quick practice a question from question bank
  const handlePracticeQuestion = (bankQ: BankQuestion) => {
    setSetupInitialOptions({
      role: bankQ.roleTag === 'Java Backend' ? 'Java Backend Developer' : 'Software Engineer',
      mode: bankQ.category.includes('DSA') ? 'CODING' : (bankQ.category.includes('HR') ? 'BEHAVIORAL' : 'TECHNICAL'),
      totalQuestions: 3
    });
    setIsSetupOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSetup={() => {
          setSetupInitialOptions({});
          setIsSetupOpen(true);
        }}
        currentUser={currentUser}
        interviewActive={!!currentInterview && currentInterview.status === 'IN_PROGRESS'}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* TAB 1: SIMULATOR */}
        {activeTab === 'simulator' && (
          <div>
            {currentInterview && currentInterview.status === 'IN_PROGRESS' ? (
              <InterviewRoom
                interview={currentInterview}
                onEvaluateAnswer={handleEvaluateAnswer}
                onFinishInterview={handleFinishInterview}
                isSubmitting={isSubmitting}
              />
            ) : currentInterview && currentInterview.status === 'COMPLETED' ? (
              <EvaluationReport
                interview={currentInterview}
                onRetake={() => {
                  setCurrentInterview(null);
                  setIsSetupOpen(true);
                }}
                onExploreBackend={() => setActiveTab('backend')}
              />
            ) : (
              /* Hero Landing / Launchpad when no active session */
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
                
                {/* Hero Card */}
                <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-indigo-950/40 via-slate-900 to-slate-950 border border-slate-800 p-8 sm:p-12 shadow-2xl text-center space-y-6">
                  
                  {/* Subtle Glow Backdrop */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-48 bg-indigo-500/10 blur-3xl pointer-events-none rounded-full" />

                  <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>Campus Placement Preparation Engine</span>
                  </div>

                  <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight max-w-4xl mx-auto leading-tight">
                    Ace Your College Campus Interviews with <span className="bg-gradient-to-r from-indigo-400 via-sky-300 to-teal-300 bg-clip-text text-transparent">AI Voice & Live Rubrics</span>
                  </h1>

                  <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
                    Designed specifically for college students and freshers. Practice high-frequency technical questions, live code scratchpad, real-time voice speech recognition, and instant campus hiring rubrics.
                  </p>

                  <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
                    <button
                      onClick={() => setIsSetupOpen(true)}
                      className="flex items-center space-x-2 px-7 py-3.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-extrabold text-sm sm:text-base rounded-2xl shadow-xl shadow-indigo-600/30 transition-all hover:scale-105"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>Start Mock Interview</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => setActiveTab('bank')}
                      className="flex items-center space-x-2 px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-200 font-bold text-sm sm:text-base rounded-2xl border border-slate-700 transition"
                    >
                      <BookOpen className="w-4 h-4 text-indigo-400" />
                      <span>Browse 50+ Placement Qs</span>
                    </button>
                  </div>

                  {/* Highlights Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 max-w-4xl mx-auto text-left">
                    <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                      <div className="flex items-center space-x-1.5 text-indigo-400 text-xs font-bold">
                        <Mic className="w-3.5 h-3.5" />
                        <span>Voice AI Interviewer</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Speaks questions and listens to verbal candidate answers</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                      <div className="flex items-center space-x-1.5 text-sky-400 text-xs font-bold">
                        <Video className="w-3.5 h-3.5" />
                        <span>Webcam & Posture</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Simulate authentic virtual video interviews with camera feedback</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                      <div className="flex items-center space-x-1.5 text-emerald-400 text-xs font-bold">
                        <Award className="w-3.5 h-3.5" />
                        <span>Campus Rubric /100</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Technical depth, communication, STAR logic, and confidence</p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                      <div className="flex items-center space-x-1.5 text-purple-400 text-xs font-bold">
                        <Server className="w-3.5 h-3.5" />
                        <span>Spring Boot & JPA</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Full backend architecture with JPA, MySQL, and REST controllers</p>
                    </div>
                  </div>

                </div>

                {/* Popular Placement Roles Quick Launcher */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-xl font-bold text-white">Select a Role to Practice Immediately</h2>
                      <p className="text-xs text-slate-400">Tailored question sets matching the exact hiring bar of top firms</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      {
                        title: 'Java Backend Developer',
                        desc: 'HashMap mechanics, Spring Boot IoC, JPA, REST APIs, SQL transactions, multi-threading.',
                        tags: ['Spring Boot', 'MySQL', 'OOPs'],
                        role: 'Java Backend Developer',
                        badge: 'Most Popular'
                      },
                      {
                        title: 'Software Engineer (General)',
                        desc: 'Core Data Structures, Two-pointer algorithms, Operating Systems, Networking, Polymorphism.',
                        tags: ['DSA', 'CS Fundamentals', 'Algorithms'],
                        role: 'Software Engineer',
                        badge: 'FAANG / Tier-1'
                      },
                      {
                        title: 'Frontend React Developer',
                        desc: 'React Fiber, Virtual DOM, useEffect lifecycle, hooks, state management, web performance.',
                        tags: ['React 19', 'JavaScript', 'CSS'],
                        role: 'Frontend React Developer',
                        badge: 'High Demand'
                      },
                      {
                        title: 'HR & Behavioral Screening',
                        desc: 'STAR method, handling project roadblocks, explaining technical trade-offs, college hackathons.',
                        tags: ['STAR Method', 'Culture', 'Leadership'],
                        role: 'HR & Behavioral',
                        badge: 'Crucial Round'
                      }
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        onClick={() => {
                          setSetupInitialOptions({ role: item.role });
                          setIsSetupOpen(true);
                        }}
                        className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/40 transition-all cursor-pointer group flex flex-col justify-between shadow-lg"
                      >
                        <div className="space-y-2.5">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                              {item.badge}
                            </span>
                            <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 group-hover:translate-x-1 transition" />
                          </div>

                          <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition">
                            {item.title}
                          </h3>

                          <p className="text-xs text-slate-400 leading-relaxed">
                            {item.desc}
                          </p>
                        </div>

                        <div className="flex flex-wrap gap-1.5 pt-4 mt-2 border-t border-slate-800/80">
                          {item.tags.map(t => (
                            <span key={t} className="px-2 py-0.5 text-[10px] rounded bg-slate-950 text-slate-300 border border-slate-800">
                              {t}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Architecture Banner */}
                <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/20 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="space-y-2 text-center md:text-left">
                    <div className="inline-flex items-center space-x-1.5 text-xs font-bold text-emerald-400 uppercase tracking-wider">
                      <Code2 className="w-4 h-4" />
                      <span>Built with Clean Full-Stack Architecture</span>
                    </div>
                    <h3 className="text-xl font-bold text-white">
                      Explore the Complete Java Spring Boot Backend Code
                    </h3>
                    <p className="text-xs text-slate-300 max-w-xl">
                      Inspect the Controller → Service → Repository → Entity layers, JPA queries, and MySQL/PostgreSQL schema designed for enterprise systems.
                    </p>
                  </div>

                  <button
                    onClick={() => setActiveTab('backend')}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition hover:scale-105 shrink-0"
                  >
                    Open Spring Boot Explorer
                  </button>
                </div>

              </div>
            )}
          </div>
        )}

        {/* TAB 2: QUESTION BANK */}
        {activeTab === 'bank' && (
          <QuestionBankView onPracticeQuestion={handlePracticeQuestion} />
        )}

        {/* TAB 3: QUICK FLASHCARDS */}
        {activeTab === 'flashcards' && (
          <QuickPracticeFlashcards />
        )}

        {/* TAB 4: ANALYTICS & HISTORY */}
        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            interviews={interviews}
            stats={stats}
            onSelectInterview={(item) => {
              setCurrentInterview(item);
              setActiveTab('simulator');
            }}
            onNewInterview={() => {
              setSetupInitialOptions({});
              setIsSetupOpen(true);
            }}
          />
        )}

        {/* TAB 5: SPRING BOOT & JPA BACKEND EXPLORER */}
        {activeTab === 'backend' && (
          <SpringBootExplorer />
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-xs text-slate-500 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            AI-Based Mock Interview Simulator • Full-Stack Platform for Campus Placement Success
          </div>
          <div className="flex items-center space-x-4">
            <span>Spring Boot 3.2</span>
            <span>•</span>
            <span>Spring Data JPA / Hibernate</span>
            <span>•</span>
            <span>React 19 & Tailwind</span>
          </div>
        </div>
      </footer>

      {/* Interview Setup Modal */}
      <SetupInterviewModal
        isOpen={isSetupOpen}
        onClose={() => setIsSetupOpen(false)}
        onStart={handleStartInterview}
        isLoading={isLoading}
        initialOptions={setupInitialOptions}
      />

    </div>
  );
}
