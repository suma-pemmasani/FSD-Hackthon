export type InterviewCategory = 'TECHNICAL' | 'CODING' | 'BEHAVIORAL' | 'SYSTEM_DESIGN';

export type HireRecommendation = 'STRONG_HIRE' | 'HIRE' | 'LEAN_HIRE' | 'NO_HIRE';

export interface User {
  id: number;
  name: string;
  email: string;
  college?: string;
  graduationYear?: number;
  targetRole?: string;
  experienceLevel?: string;
  createdAt: string;
}

export interface Evaluation {
  id?: number;
  evaluationId?: number;
  answerId?: number;
  questionId?: number;
  technicalScore: number;     // 0 - 25
  communicationScore: number; // 0 - 25
  structureScore: number;     // 0 - 25
  confidenceScore: number;    // 0 - 25
  overallScore: number;       // 0 - 100
  strengths: string[];
  improvements: string[];
  missingKeywords: string[];
  modelAnswer: string;
  feedback: string;
  hireRecommendation: HireRecommendation;
}

export interface Answer {
  id?: number;
  questionId: number;
  candidateAnswer: string;
  codeSnippet?: string;
  durationSeconds?: number;
  submittedAt?: string;
  evaluation?: Evaluation;
}

export interface Question {
  id: number;
  interviewId?: number;
  questionOrder: number;
  category: InterviewCategory;
  questionText: string;
  expectedTopics?: string;
  sampleAnswer?: string;
  starterCode?: string;
  answer?: Answer;
}

export interface Interview {
  id: number;
  userId: number;
  userName: string;
  role: string;
  companyType: string;
  difficulty: string;
  interviewerName: string;
  totalQuestions: number;
  status: 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  overallScore: number;
  hireDecision?: HireRecommendation;
  summaryFeedback?: string;
  createdAt: string;
  completedAt?: string;
  questions: Question[];
}

export interface InterviewSetupOptions {
  name: string;
  email: string;
  college: string;
  graduationYear: number;
  role: string;
  companyType: string;
  difficulty: string;
  interviewerName: string;
  totalQuestions: number;
  mode: string;
  customTopics: string[];
}

export interface PlatformStats {
  totalInterviews: number;
  averageScore: number;
  activeCandidates: number;
  hireRatePercentage: number;
  topRoles: Array<{ role: string; count: number }>;
}

export interface SpringBootFile {
  path: string;
  name: string;
  content: string;
  language: string;
}
