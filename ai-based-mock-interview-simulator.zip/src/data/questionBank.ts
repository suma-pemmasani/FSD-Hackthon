export interface BankQuestion {
  id: string;
  category: 'Java / Backend' | 'DSA / Coding' | 'Frontend / React' | 'System Design' | 'HR & Behavioral' | 'DBMS / SQL';
  roleTag: string;
  title: string;
  difficulty: 'Fresher' | 'Junior' | 'Moderate';
  frequency: 'High' | 'Very High' | 'Crucial';
  companyTags: string[];
  expectedKeywords: string[];
  questionText: string;
  modelAnswer: string;
  keyConcepts: string[];
  starGuide?: {
    situation: string;
    task: string;
    action: string;
    result: string;
  };
}

export const QUESTION_BANK: BankQuestion[] = [
  {
    id: 'java-01',
    category: 'Java / Backend',
    roleTag: 'Java Backend',
    title: 'HashMap Internal Architecture & Hash Collisions',
    difficulty: 'Fresher',
    frequency: 'Crucial',
    companyTags: ['Amazon', 'Infosys', 'TCS Digital', 'Morgan Stanley'],
    expectedKeywords: ['hashCode()', 'equals()', 'bucket index', 'LinkedList', 'Red-Black Tree', 'TREEIFY_THRESHOLD (8)'],
    questionText: 'How does HashMap work internally in Java? What happens during a hash collision and what change occurred in Java 8?',
    modelAnswer: 'Java HashMap is backed by an array of Node<K,V> buckets. When put(K, V) is invoked, it evaluates hashCode(), applies a bitwise spreading function, and computes the array index using (n - 1) & hash. If multiple keys resolve to the same index (hash collision), elements are chained into a singly linked list where equals() resolves uniqueness. In Java 8, if a bucket reaches 8 nodes and total capacity is >= 64, it automatically converts to a Red-Black Tree, decreasing search time complexity from O(n) to O(log n).',
    keyConcepts: ['Collision resolution via separate chaining', 'Treeification threshold of 8', 'Contract between equals() and hashCode()']
  },
  {
    id: 'java-02',
    category: 'Java / Backend',
    roleTag: 'Java Backend',
    title: 'Spring Boot Dependency Injection & IoC',
    difficulty: 'Fresher',
    frequency: 'Very High',
    companyTags: ['Wipro', 'Cognizant', 'Capgemini', 'Paytm'],
    expectedKeywords: ['Inversion of Control', 'ApplicationContext', 'Constructor Injection', 'Bean Lifecycle', 'Immutability'],
    questionText: 'What is Inversion of Control (IoC) and Dependency Injection (DI) in Spring Boot? Why is constructor injection preferred over @Autowired field injection?',
    modelAnswer: 'IoC is a design principle where the control of object creation, configuration, and lifecycle management is inverted and handed over to the Spring Container (ApplicationContext). Dependency Injection is the architectural pattern that implements IoC. Constructor injection is preferred because it makes dependencies explicit, enforces immutability by allowing fields to be declared as final, ensures objects cannot be instantiated in a partially constructed state, simplifies unit testing with mocks, and detects circular dependencies at startup.',
    keyConcepts: ['Loose coupling', 'IoC container bean registry', 'Constructor vs Field injection']
  },
  {
    id: 'java-03',
    category: 'Java / Backend',
    roleTag: 'Java Backend',
    title: 'String vs StringBuilder vs StringBuffer',
    difficulty: 'Fresher',
    frequency: 'Very High',
    companyTags: ['Accenture', 'TCS', 'HCL', 'Tech Mahindra'],
    expectedKeywords: ['Immutability', 'String Constant Pool', 'Thread-safety', 'Synchronized', 'Heap allocation'],
    questionText: 'Explain the difference between String, StringBuilder, and StringBuffer in Java with respect to memory and thread safety.',
    modelAnswer: 'String objects are immutable in Java; every modification creates a new object in the String Constant Pool or heap, leading to memory overhead in loops. StringBuffer is mutable and thread-safe because its public methods are synchronized, which introduces a slight synchronization performance cost. StringBuilder is also mutable but non-synchronized, making it the most performant choice for single-threaded string concatenation operations.',
    keyConcepts: ['String immutability for security and caching', 'Thread synchronization overhead', 'Memory optimization']
  },
  {
    id: 'dsa-01',
    category: 'DSA / Coding',
    roleTag: 'Software Engineer',
    title: 'Two Sum in O(N) Time Complexity',
    difficulty: 'Fresher',
    frequency: 'Crucial',
    companyTags: ['Google', 'Microsoft', 'Adobe', 'Uber'],
    expectedKeywords: ['Hash Map', 'Complement', 'O(N) Time', 'O(N) Auxiliary Space', 'Single pass'],
    questionText: 'Given an array of integers, how do you find two distinct indices whose values sum to a specific target in O(N) time?',
    modelAnswer: 'A naive nested loop approach runs in O(N²) time. To optimize to O(N), we use a Hash Map storing value-to-index mappings. As we iterate through each number x at index i, we calculate its complement (target - x). If complement is present in the hash map, we immediately return [map.get(complement), i]. If not, we store x and its index i. This single pass operates in O(N) time and O(N) auxiliary space.',
    keyConcepts: ['Trading space for time', 'O(1) average hash lookup', 'Handling duplicate values cleanly']
  },
  {
    id: 'dsa-02',
    category: 'DSA / Coding',
    roleTag: 'Software Engineer',
    title: 'Detect Cycle in a Singly Linked List',
    difficulty: 'Fresher',
    frequency: 'Crucial',
    companyTags: ['Amazon', 'Flipkart', 'Cisco', 'Goldman Sachs'],
    expectedKeywords: ["Floyd's Cycle Algorithm", 'Tortoise and Hare', 'Slow pointer', 'Fast pointer', 'O(1) Space'],
    questionText: "How do you detect whether a Singly Linked List contains a cycle without using extra memory? Explain Floyd's Algorithm.",
    modelAnswer: "We use Floyd's Tortoise and Hare Cycle-Finding Algorithm. We initialize two pointers: slow and fast, both pointing to the head. In each iteration, slow advances 1 node while fast advances 2 nodes. If fast or fast.next reaches null, the list terminates with no cycle. If the two pointers meet at the same node, a cycle exists. This operates in O(N) time complexity and O(1) space complexity.",
    keyConcepts: ['Two-pointer technique', 'Mathematical proof of convergence', 'Space-efficient traversal']
  },
  {
    id: 'frontend-01',
    category: 'Frontend / React',
    roleTag: 'Frontend React',
    title: 'React Virtual DOM and Reconciliation (Fiber)',
    difficulty: 'Fresher',
    frequency: 'Crucial',
    companyTags: ['Meta', 'Uber', 'Swiggy', 'Zomato'],
    expectedKeywords: ['Virtual DOM', 'Reconciliation', 'Fiber tree', 'Key prop stability', 'Batch updates'],
    questionText: 'What is the Virtual DOM and how does React reconciliation work? Why is using array index as a key prop discouraged?',
    modelAnswer: 'The Virtual DOM is a lightweight JavaScript object representation of the real DOM tree. When component state changes, React creates a new virtual tree and runs a diffing algorithm (Reconciliation using the Fiber engine) to calculate the minimum mutations needed, then commits them in batches. Using array index as keys is problematic when items are inserted, deleted, or reordered; React reuses component instances based on keys, resulting in corrupted input states and unintended re-renders.',
    keyConcepts: ['Diffing heuristic O(n)', 'Render vs Commit phases', 'Component key stability']
  },
  {
    id: 'frontend-02',
    category: 'Frontend / React',
    roleTag: 'Frontend React',
    title: 'React useEffect Lifecycle and Memory Leak Prevention',
    difficulty: 'Fresher',
    frequency: 'Very High',
    companyTags: ['Razorpay', 'CRED', 'Jio', 'Freshworks'],
    expectedKeywords: ['Dependency array', 'Cleanup function', 'Stale closure', 'AbortController', 'Component unmount'],
    questionText: 'How does useEffect handle component lifecycle? How do you prevent memory leaks when listening to events or fetching data?',
    modelAnswer: 'useEffect executes after render. With an empty dependency array [], it executes once on mount. With dependencies [a, b], it runs whenever those values change. To prevent memory leaks, you return a cleanup function from the effect callback. In this cleanup function, you remove event listeners, clear timers (clearInterval), or abort pending HTTP requests using AbortController.abort().',
    keyConcepts: ['Side-effect cleanup', 'Avoid infinite re-render loops', 'Dependency array hygiene']
  },
  {
    id: 'dbms-01',
    category: 'DBMS / SQL',
    roleTag: 'Java Backend',
    title: 'ACID Properties in Relational Databases',
    difficulty: 'Fresher',
    frequency: 'Crucial',
    companyTags: ['Oracle', 'SAP', 'Barclays', 'Walmart Global Tech'],
    expectedKeywords: ['Atomicity', 'Consistency', 'Isolation', 'Durability', 'Transactions', 'Write-Ahead Logging'],
    questionText: 'Explain the ACID properties of a DBMS with an example of an online bank transfer.',
    modelAnswer: 'ACID guarantees reliable transaction processing. Atomicity: The entire transaction succeeds or rolls back completely (if debit from account A succeeds but credit to account B fails, both roll back). Consistency: The database transitions from one valid state to another, preserving constraints (total balance remains constant). Isolation: Concurrent transactions do not interfere with each other (read/write locks prevent dirty reads). Durability: Once committed, updates are permanently preserved on non-volatile storage even across power outages via write-ahead logging.',
    keyConcepts: ['Transaction rollbacks', 'Isolation levels (Read Committed, Serializable)', 'Write-Ahead Log (WAL)']
  },
  {
    id: 'dbms-02',
    category: 'DBMS / SQL',
    roleTag: 'Java Backend',
    title: 'Indexing & B+ Trees in Databases',
    difficulty: 'Fresher',
    frequency: 'Very High',
    companyTags: ['Microsoft', 'Infosys', 'Cognizant', 'Dell'],
    expectedKeywords: ['B+ Tree', 'Clustered Index', 'Non-clustered Index', 'Full table scan', 'O(log N) lookup'],
    questionText: 'How do database indexes improve query performance? Why are B+ Trees used instead of standard Binary Search Trees for disk storage?',
    modelAnswer: 'Indexes are data structures (typically B+ Trees) that allow the database engine to find specific rows in O(log N) disk reads rather than doing an expensive O(N) full table scan. B+ Trees are preferred over binary trees because they have high fan-out (hundreds of child pointers per node), which minimizes disk I/O operations. Furthermore, all leaf nodes in a B+ Tree are sequentially linked, enabling blazing-fast range queries (BETWEEN, >=, <=).',
    keyConcepts: ['Clustered vs Non-clustered index', 'Minimizing disk seek latency', 'Sequential leaf node pointers']
  },
  {
    id: 'hr-01',
    category: 'HR & Behavioral',
    roleTag: 'HR & Behavioral',
    title: 'Overcoming a Difficult Project Challenge (STAR Method)',
    difficulty: 'Fresher',
    frequency: 'Crucial',
    companyTags: ['All Major Recruiters', 'FAANG', 'Product & Service IT'],
    expectedKeywords: ['Situation', 'Task', 'Action', 'Result', 'Accountability', 'Technical resolution'],
    questionText: 'Tell me about a time you faced a major roadblock or technical bug in your college final year project. How did you resolve it?',
    modelAnswer: 'In my final-year project, our real-time video chat feature experienced extreme lag during multi-peer testing. As the team lead, my task was to diagnose the bottleneck before our department demo. I profiled network packets using Wireshark, discovered redundant STUN server handshakes, and migrated our architecture to WebRTC mesh with local media track caching. As a result, connection latency dropped by 65% and our project won first place at our college symposium.',
    keyConcepts: ['STAR storytelling structure', 'Taking ownership', 'Quantifiable positive impact'],
    starGuide: {
      situation: 'Describe the context: college course, team size, project goal, and the unexpected crisis.',
      task: 'State clearly what your specific individual responsibility was to solve it.',
      action: 'Detail the concrete engineering actions you took: debugging, profiling, consulting docs.',
      result: 'Highlight the outcome: metrics (e.g. 50% faster, zero crashes), team praise, and what you learned.'
    }
  },
  {
    id: 'hr-02',
    category: 'HR & Behavioral',
    roleTag: 'HR & Behavioral',
    title: 'Why Should We Hire You as a College Fresher?',
    difficulty: 'Fresher',
    frequency: 'Crucial',
    companyTags: ['TCS', 'Infosys', 'Accenture', 'Cognizant', 'Capgemini'],
    expectedKeywords: ['Quick learner', 'Strong CS fundamentals', 'Adaptability', 'Positive attitude', 'Mentorship'],
    questionText: 'Why should we hire you over other candidates from your college graduating batch?',
    modelAnswer: 'You should hire me because I combine strong computer science fundamentals in data structures, OOP, and Spring Boot with an active track record of building production-grade web projects rather than just theoretical coursework. I have proven adaptability by picking up new technologies quickly during 36-hour hackathons, and I am eager to contribute with a humble, high-energy mindset under senior mentorship.',
    keyConcepts: ['Confidence without arrogance', 'Proof of building real projects', 'Commitment to long-term growth']
  }
];
