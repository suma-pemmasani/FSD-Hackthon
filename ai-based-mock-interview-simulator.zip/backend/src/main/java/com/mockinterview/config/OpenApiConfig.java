package com.mockinterview.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI mockInterviewOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("AI-Based Mock Interview Simulator API")
                        .description("RESTful Backend API specification for Mock Interview platform built for college students and freshers.")
                        .version("v1.0.0")
                        .contact(new Contact()
                                .name("Engineering Career Prep")
                                .email("prep@mockinterview.ai"))
                        .license(new License().name("Apache 2.0")));
    }
}
