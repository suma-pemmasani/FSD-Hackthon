package com.mockinterview.service;

import com.mockinterview.dto.AnswerRequest;
import com.mockinterview.dto.EvaluationResponse;
import com.mockinterview.entity.Answer;
import com.mockinterview.entity.Evaluation;
import com.mockinterview.entity.Interview;
import com.mockinterview.entity.Question;
import com.mockinterview.exception.ResourceNotFoundException;
import com.mockinterview.repository.AnswerRepository;
import com.mockinterview.repository.EvaluationRepository;
import com.mockinterview.repository.InterviewRepository;
import com.mockinterview.repository.QuestionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EvaluationService {

    private final QuestionRepository questionRepository;
    private final AnswerRepository answerRepository;
    private final EvaluationRepository evaluationRepository;
    private final InterviewRepository interviewRepository;

    @Transactional
    public EvaluationResponse evaluateAnswer(AnswerRequest request) {
        Question question = questionRepository.findById(request.getQuestionId())
                .orElseThrow(() -> new ResourceNotFoundException("Question not found with id: " + request.getQuestionId()));

        Answer answer = answerRepository.findByQuestionId(request.getQuestionId())
                .orElse(Answer.builder().question(question).build());

        answer.setCandidateAnswer(request.getCandidateAnswer());
        answer.setCodeSnippet(request.getCodeSnippet());
        answer.setDurationSeconds(request.getDurationSeconds() != null ? request.getDurationSeconds() : 0);
        answer.setSubmittedAt(LocalDateTime.now());
        answer = answerRepository.save(answer);

        // Calculate rubric scores based on answer depth, length, and technical keywords
        String text = request.getCandidateAnswer().toLowerCase();
        int techScore = Math.min(25, Math.max(12, 10 + (text.length() > 120 ? 8 : 4) + (text.contains("time complexity") || text.contains("hash") || text.contains("object") ? 5 : 2)));
        int commScore = Math.min(25, Math.max(14, 12 + (text.length() > 100 ? 7 : 3) + (text.contains("for example") || text.contains("specifically") ? 5 : 2)));
        int structScore = Math.min(25, Math.max(12, 11 + (text.contains("first") || text.contains("second") || text.contains("therefore") ? 8 : 4)));
        int confScore = Math.min(25, Math.max(13, 13 + (text.length() > 80 ? 7 : 4)));

        int overall = techScore + commScore + structScore + confScore;

        List<String> strengths = Arrays.asList(
                "Clear conceptual explanation tailored for entry-level discussion",
                "Good technical terminology and logical sequence",
                "Demonstrated practical understanding of tradeoffs"
        );

        List<String> improvements = Arrays.asList(
                "Include concrete edge cases (e.g. null inputs, boundary conditions)",
                "State Big-O time and space complexity explicitly upfront",
                "Relate concepts to hands-on academic or personal projects"
        );

        List<String> missingKeywords = Arrays.asList("Complexity", "Edge Cases", "Scalability", "Optimization");

        String feedback = String.format("Solid response for a college fresher. Your technical points were well communicated (Score: %d/100). To elevate this to a top-tier score, practice articulating runtime complexity and real-world failure modes.", overall);

        Evaluation eval = evaluationRepository.findByAnswerId(answer.getId())
                .orElse(Evaluation.builder().answer(answer).build());

        eval.setTechnicalScore(techScore);
        eval.setCommunicationScore(commScore);
        eval.setStructureScore(structScore);
        eval.setConfidenceScore(confScore);
        eval.setOverallQuestionScore(overall);
        eval.setStrengths(String.join(";", strengths));
        eval.setImprovements(String.join(";", improvements));
        eval.setMissingKeywords(String.join(",", missingKeywords));
        eval.setModelAnswer(question.getSampleAnswer() != null ? question.getSampleAnswer() : "A comprehensive answer articulates definitions, edge cases, and architectural tradeoffs.");
        eval.setFeedback(feedback);

        eval = evaluationRepository.save(eval);

        return EvaluationResponse.builder()
                .evaluationId(eval.getId())
                .answerId(answer.getId())
                .questionId(question.getId())
                .technicalScore(techScore)
                .communicationScore(commScore)
                .structureScore(structScore)
                .confidenceScore(confScore)
                .overallScore(overall)
                .strengths(strengths)
                .improvements(improvements)
                .missingKeywords(missingKeywords)
                .modelAnswer(eval.getModelAnswer())
                .feedback(feedback)
                .hireRecommendation(overall >= 80 ? "STRONG_HIRE" : (overall >= 65 ? "HIRE" : "LEAN_HIRE"))
                .build();
    }
}
