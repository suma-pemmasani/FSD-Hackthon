package com.mockinterview.service;

import com.mockinterview.dto.UserDto;
import com.mockinterview.entity.User;
import com.mockinterview.exception.ResourceNotFoundException;
import com.mockinterview.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    @Transactional
    public User getOrCreateUser(UserDto dto) {
        return userRepository.findByEmail(dto.getEmail())
                .orElseGet(() -> {
                    User newUser = User.builder()
                            .name(dto.getName())
                            .email(dto.getEmail())
                            .college(dto.getCollege())
                            .graduationYear(dto.getGraduationYear())
                            .targetRole(dto.getTargetRole())
                            .experienceLevel(dto.getExperienceLevel() != null ? dto.getExperienceLevel() : "FRESHER")
                            .build();
                    return userRepository.save(newUser);
                });
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }
}
