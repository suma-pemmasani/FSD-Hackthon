package com.mockinterview.service;

import com.mockinterview.entity.Interview;
import com.mockinterview.entity.Question;
import com.mockinterview.repository.QuestionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class QuestionService {

    private final QuestionRepository questionRepository;

    @Transactional
    public List<Question> generateQuestionsForInterview(Interview interview, List<String> focusTopics) {
        List<Question> questions = new ArrayList<>();
        int count = interview.getTotalQuestions();
        String role = interview.getRole();

        // Standard questions tailored to college freshers based on role
        if (role.toLowerCase().contains("java") || role.toLowerCase().contains("backend")) {
            questions.add(Question.builder()
                    .interview(interview)
                    .questionOrder(1)
                    .category("TECHNICAL")
                    .questionText("Explain the difference between HashMap, HashTable, and ConcurrentHashMap in Java. What happens internally when two keys have the same hash code?")
                    .expectedTopics("Array of buckets, LinkedList, Balanced Red-Black tree in Java 8, Synchronized methods vs segment locking / CAS operations.")
                    .sampleAnswer("HashMap is non-synchronized and allows one null key. Internally uses an array of Node objects. When a collision occurs, entries form a linked list, transforming to a Red-Black tree when bucket size exceeds 8.")
                    .build());

            if (count > 1) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(2)
                        .category("TECHNICAL")
                        .questionText("How does Spring Boot's Dependency Injection and Inversion of Control (IoC) work? Explain the difference between @Component, @Service, and @Repository.")
                        .expectedTopics("IoC Container, ApplicationContext, Bean lifecycle, Stereo-type annotations and automatic persistence exception translation.")
                        .sampleAnswer("@Component is a generic stereotype for any Spring-managed component. @Service indicates service facade, while @Repository provides automatic exception translation for persistence layers.")
                        .build());
            }

            if (count > 2) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(3)
                        .category("CODING")
                        .questionText("Write a method in Java to detect if a Singly Linked List has a cycle. What are the time and space complexities?")
                        .expectedTopics("Floyd's Cycle-Finding Algorithm (Tortoise and Hare), O(N) time complexity, O(1) auxiliary space.")
                        .sampleAnswer("Use two pointers: slow moving 1 step and fast moving 2 steps. If fast equals slow, a cycle exists.")
                        .build());
            }

            if (count > 3) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(4)
                        .category("BEHAVIORAL")
                        .questionText("Tell me about a time you encountered a severe bug in your college project right before the submission deadline. How did you resolve it?")
                        .expectedTopics("STAR framework: Situation, Task, Action (systematic debugging, logging, isolating issue), Result (timely submission, learnings).")
                        .sampleAnswer("In my final-year project, our authentication token broke during live demo staging. I used network inspection, identified a missing CORS header, implemented the fix, and created automated curl sanity scripts.")
                        .build());
            }

            if (count > 4) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(5)
                        .category("TECHNICAL")
                        .questionText("What is the difference between SQL and NoSQL databases? When would you choose PostgreSQL over MongoDB for a college e-commerce project?")
                        .expectedTopics("ACID compliance, schema rigidity, transactions, relational foreign keys, vertical vs horizontal scaling.")
                        .sampleAnswer("PostgreSQL provides strict schema validation and ACID guarantees critical for financial transactions and inventory management, whereas MongoDB offers flexible JSON documents.")
                        .build());
            }
        } else {
            // General Software Engineer / Full Stack
            questions.add(Question.builder()
                    .interview(interview)
                    .questionOrder(1)
                    .category("TECHNICAL")
                    .questionText("What are the fundamental principles of Object-Oriented Programming (OOP)? Can you give a real-world software design example demonstrating Polymorphism?")
                    .expectedTopics("Encapsulation, Abstraction, Inheritance, Polymorphism (compile-time overloading and runtime method overriding).")
                    .sampleAnswer("Polymorphism allows objects to take multiple forms. For instance, a PaymentGateway interface with executePayment() implemented differently by PayPalGateway and StripeGateway.")
                    .build());

            if (count > 1) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(2)
                        .category("CODING")
                        .questionText("Given an array of integers, how would you find the 'Two Sum' indices that add up to a target number in O(N) time? Explain your approach.")
                        .expectedTopics("Hash Table / Map lookup in O(1) average time, tracking complement target - nums[i].")
                        .sampleAnswer("Iterate through the array while storing visited elements in a Hash Map. For each element, check if (target - num) exists in the map.")
                        .build());
            }

            if (count > 2) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(3)
                        .category("BEHAVIORAL")
                        .questionText("Why do you want to join our company as a fresher? What technical areas are you most excited to learn in your first 6 months?")
                        .expectedTopics("Enthusiasm, curiosity, alignment with engineering culture, proactive learning mindset.")
                        .sampleAnswer("I admire the company's focus on scalable systems and engineering mentorship. In my first six months, I aim to master production CI/CD, microservices observability, and contribute to core features.")
                        .build());
            }

            if (count > 3) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(4)
                        .category("TECHNICAL")
                        .questionText("Explain the difference between REST and GraphQL APIs. What are over-fetching and under-fetching?")
                        .expectedTopics("Fixed endpoint responses vs query-specified payload, HTTP methods, caching headers.")
                        .sampleAnswer("REST exposes fixed resource endpoints. Under-fetching requires multiple round trips; over-fetching downloads unnecessary fields. GraphQL lets the client specify exact fields.")
                        .build());
            }

            if (count > 4) {
                questions.add(Question.builder()
                        .interview(interview)
                        .questionOrder(5)
                        .category("TECHNICAL")
                        .questionText("What is the difference between Process and Thread? How do operating systems handle context switching?")
                        .expectedTopics("Memory space sharing, virtual memory, PCB, TCB, CPU registers.")
                        .sampleAnswer("A process is an executing program instance with isolated memory space. Threads exist within a process and share heap memory, making context switching cheaper.")
                        .build());
            }
        }

        return questionRepository.saveAll(questions);
    }
}
