package com.mockinterview.service;

import com.mockinterview.dto.InterviewRequest;
import com.mockinterview.entity.Interview;
import com.mockinterview.entity.Question;
import com.mockinterview.entity.User;
import com.mockinterview.exception.ResourceNotFoundException;
import com.mockinterview.repository.InterviewRepository;
import com.mockinterview.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InterviewService {

    private final InterviewRepository interviewRepository;
    private final UserRepository userRepository;
    private final QuestionService questionService;

    @Transactional
    public Interview startInterview(InterviewRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + request.getUserId()));

        Interview interview = Interview.builder()
                .user(user)
                .role(request.getRole())
                .companyType(request.getCompanyType() != null ? request.getCompanyType() : "Standard Tech")
                .difficulty(request.getDifficulty())
                .totalQuestions(request.getTotalQuestions() != null ? request.getTotalQuestions() : 5)
                .status("IN_PROGRESS")
                .createdAt(LocalDateTime.now())
                .build();

        Interview savedInterview = interviewRepository.save(interview);
        List<Question> questions = questionService.generateQuestionsForInterview(savedInterview, request.getFocusTopics());
        savedInterview.setQuestions(questions);

        return savedInterview;
    }

    public Interview getInterviewById(Long id) {
        return interviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Interview not found with id: " + id));
    }

    public List<Interview> getUserInterviews(Long userId) {
        return interviewRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    @Transactional
    public Interview finalizeInterview(Long interviewId) {
        Interview interview = getInterviewById(interviewId);

        // Calculate average score from questions/evaluations
        int totalScore = 0;
        int evaluatedCount = 0;

        for (Question q : interview.getQuestions()) {
            if (q.getAnswer() != null && q.getAnswer().getEvaluation() != null) {
                totalScore += q.getAnswer().getEvaluation().getOverallQuestionScore();
                evaluatedCount++;
            }
        }

        int finalScore = evaluatedCount > 0 ? (totalScore / evaluatedCount) : 75;
        interview.setOverallScore(finalScore);
        interview.setStatus("COMPLETED");
        interview.setCompletedAt(LocalDateTime.now());

        if (finalScore >= 85) {
            interview.setHireDecision("STRONG_HIRE");
            interview.setSummaryFeedback("Outstanding interview! You demonstrated exceptional fundamentals, structured thinking, and confident articulation suitable for tier-1 tech companies.");
        } else if (finalScore >= 70) {
            interview.setHireDecision("HIRE");
            interview.setSummaryFeedback("Good performance with sound conceptual knowledge. You communicated clearly and solved standard problems with minor nudges.");
        } else if (finalScore >= 55) {
            interview.setHireDecision("LEAN_HIRE");
            interview.setSummaryFeedback("Promising potential but needs deeper revision on core data structures, corner cases, and structured problem articulation.");
        } else {
            interview.setHireDecision("NO_HIRE");
            interview.setSummaryFeedback("Requires substantial preparation in foundational CS principles, hands-on coding practice, and behavioral response structuring.");
        }

        return interviewRepository.save(interview);
    }
}
