package com.mockinterview.dto;

import lombok.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationResponse {

    private Long evaluationId;
    private Long answerId;
    private Long questionId;

    private Integer technicalScore;     // 0 - 25
    private Integer communicationScore; // 0 - 25
    private Integer structureScore;     // 0 - 25
    private Integer confidenceScore;    // 0 - 25
    private Integer overallScore;       // 0 - 100

    private List<String> strengths;
    private List<String> improvements;
    private List<String> missingKeywords;
    private String modelAnswer;
    private String feedback;
    private String hireRecommendation;  // STRONG_HIRE, HIRE, LEAN_HIRE, NO_HIRE
}
