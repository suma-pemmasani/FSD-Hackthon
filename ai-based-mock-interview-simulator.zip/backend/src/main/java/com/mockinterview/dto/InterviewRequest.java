package com.mockinterview.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InterviewRequest {

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotBlank(message = "Target role is required")
    private String role; // e.g. "Software Engineer", "Java Backend Developer", "Frontend React Developer"

    private String companyType; // "FAANG / Big Tech", "Product Startup", "IT Services"

    @NotBlank(message = "Difficulty is required")
    private String difficulty; // "FRESHER", "JUNIOR", "MID"

    @Min(value = 1, message = "Total questions must be at least 1")
    private Integer totalQuestions;

    private String mode; // "MIXED", "CODING", "TECHNICAL", "BEHAVIORAL"

    private List<String> focusTopics;
}
