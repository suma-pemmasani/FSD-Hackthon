package com.mockinterview.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "evaluations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Evaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "answer_id", nullable = false, unique = true)
    private Answer answer;

    @Column(nullable = false)
    private Integer technicalScore; // 0-25

    @Column(nullable = false)
    private Integer communicationScore; // 0-25

    @Column(nullable = false)
    private Integer structureScore; // 0-25

    @Column(nullable = false)
    private Integer confidenceScore; // 0-25

    @Column(nullable = false)
    private Integer overallQuestionScore; // 0-100

    @Column(columnDefinition = "TEXT")
    private String strengths;

    @Column(columnDefinition = "TEXT")
    private String improvements;

    @Column(columnDefinition = "TEXT")
    private String modelAnswer;

    @Column(columnDefinition = "TEXT")
    private String missingKeywords;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String feedback;
}
