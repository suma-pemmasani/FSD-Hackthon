package com.mockinterview.controller;

import com.mockinterview.dto.AnswerRequest;
import com.mockinterview.dto.EvaluationResponse;
import com.mockinterview.service.EvaluationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/evaluations")
@RequiredArgsConstructor
@Tag(name = "AI Evaluation", description = "AI scoring and feedback on candidate responses")
public class EvaluationController {

    private final EvaluationService evaluationService;

    @PostMapping("/evaluate-answer")
    @Operation(summary = "Submit answer and receive immediate rubric breakdown & feedback")
    public ResponseEntity<EvaluationResponse> evaluateAnswer(@Valid @RequestBody AnswerRequest request) {
        EvaluationResponse evaluation = evaluationService.evaluateAnswer(request);
        return ResponseEntity.ok(evaluation);
    }
}
