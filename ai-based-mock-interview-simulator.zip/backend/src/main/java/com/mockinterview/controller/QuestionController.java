package com.mockinterview.controller;

import com.mockinterview.entity.Question;
import com.mockinterview.repository.QuestionRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/questions")
@RequiredArgsConstructor
@Tag(name = "Questions", description = "Query questions assigned to mock interviews")
public class QuestionController {

    private final QuestionRepository questionRepository;

    @GetMapping("/interview/{interviewId}")
    @Operation(summary = "Get all questions for an interview ordered by question number")
    public ResponseEntity<List<Question>> getQuestionsByInterview(@PathVariable Long interviewId) {
        return ResponseEntity.ok(questionRepository.findByInterviewIdOrderByQuestionOrderAsc(interviewId));
    }
}
