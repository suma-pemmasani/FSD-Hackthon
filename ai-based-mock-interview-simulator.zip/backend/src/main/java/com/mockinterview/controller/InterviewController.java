package com.mockinterview.controller;

import com.mockinterview.dto.InterviewRequest;
import com.mockinterview.entity.Interview;
import com.mockinterview.service.InterviewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/interviews")
@RequiredArgsConstructor
@Tag(name = "Interview Flow", description = "Endpoints for initiating and completing mock interview sessions")
public class InterviewController {

    private final InterviewService interviewService;

    @PostMapping
    @Operation(summary = "Start a new mock interview session with tailored questions")
    public ResponseEntity<Interview> startInterview(@Valid @RequestBody InterviewRequest request) {
        Interview interview = interviewService.startInterview(request);
        return ResponseEntity.ok(interview);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get interview session details, questions, answers and evaluations")
    public ResponseEntity<Interview> getInterviewById(@PathVariable Long id) {
        return ResponseEntity.ok(interviewService.getInterviewById(id));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "List all past interviews for a given candidate")
    public ResponseEntity<List<Interview>> getUserInterviews(@PathVariable Long userId) {
        return ResponseEntity.ok(interviewService.getUserInterviews(userId));
    }

    @PostMapping("/{id}/finalize")
    @Operation(summary = "Finalize interview and compute comprehensive report card")
    public ResponseEntity<Interview> finalizeInterview(@PathVariable Long id) {
        Interview completed = interviewService.finalizeInterview(id);
        return ResponseEntity.ok(completed);
    }
}
