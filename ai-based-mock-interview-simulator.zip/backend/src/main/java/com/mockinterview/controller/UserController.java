package com.mockinterview.controller;

import com.mockinterview.dto.UserDto;
import com.mockinterview.entity.User;
import com.mockinterview.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "User Management", description = "Endpoints for managing college fresher profiles")
public class UserController {

    private final UserService userService;

    @PostMapping
    @Operation(summary = "Create or retrieve candidate profile")
    public ResponseEntity<User> getOrCreateUser(@Valid @RequestBody UserDto dto) {
        User user = userService.getOrCreateUser(dto);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get user details by ID")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }
}
