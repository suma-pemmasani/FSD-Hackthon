-- Schema for AI-Based Mock Interview Simulator
-- Compatible with MySQL and PostgreSQL

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    college VARCHAR(150),
    graduation_year INT,
    target_role VARCHAR(100),
    experience_level VARCHAR(50) DEFAULT 'FRESHER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS interviews (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    role VARCHAR(100) NOT NULL,
    company_type VARCHAR(100),
    difficulty VARCHAR(50) NOT NULL,
    total_questions INT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'IN_PROGRESS',
    overall_score INT DEFAULT 0,
    hire_decision VARCHAR(50),
    summary_feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS questions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    interview_id BIGINT NOT NULL,
    question_order INT NOT NULL,
    category VARCHAR(50) NOT NULL,
    question_text TEXT NOT NULL,
    expected_topics TEXT,
    sample_answer TEXT,
    FOREIGN KEY (interview_id) REFERENCES interviews(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS answers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    question_id BIGINT NOT NULL,
    candidate_answer TEXT NOT NULL,
    code_snippet TEXT,
    duration_seconds INT DEFAULT 0,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS evaluations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    answer_id BIGINT NOT NULL UNIQUE,
    technical_score INT NOT NULL,
    communication_score INT NOT NULL,
    structure_score INT NOT NULL,
    confidence_score INT NOT NULL,
    overall_question_score INT NOT NULL,
    strengths TEXT,
    improvements TEXT,
    model_answer TEXT,
    missing_keywords TEXT,
    feedback TEXT NOT NULL,
    FOREIGN KEY (answer_id) REFERENCES answers(id) ON DELETE CASCADE
);
